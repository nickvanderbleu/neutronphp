<?php

require_once("system/core/classes/tools.php");

if($tools->checkFile($tools->sysDir.$tools->ds."init.php") == 1)
{
	require_once($tools->sysDir.$tools->ds."init.php");
}
else
{
	echo "<div class='systemBar error' style='display:block;'>The initialization file is invalid</div>";
	exit;	
}