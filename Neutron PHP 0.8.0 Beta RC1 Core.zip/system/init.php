<?php

require_once("core/classes/tools.php");

if($tools->checkFile($_SESSION['configPath']."/connect.ini") == 1)
{
	
	require_once("core/autoload.php");
	
	if($pages->checkPage($pages->pageIndex) == 1)
	{
		if($_SERVER['REQUEST_URI'] == '/')
		{
			$templates->loadTemplate($_SESSION['config']['siteTheme'], $pages->pageIndex);
		}
		else
		{
			if($templates->dir == '/admin')
			{
				$templates->loadTemplate($_SESSION['config']['adminTheme'], $pages->pageIndex);
			}
			else
			{
				$templates->loadTemplate($_SESSION['config']['defaultTheme'], $pages->pageIndex);
			}
		}		
	}
	else
	{
		echo "<div class='systemBar error' style='display:block;'>The page your requested has been disabled by the system administrator</div>";
		exit;			
	}
}
else
{
	echo "<div class='systemBar error' style='display:block;'>The application has not been configured. Please check with your system administrator or click <a href='/install/login.php?cmd=login'>here</a> to install</div>";
	exit;			
}



