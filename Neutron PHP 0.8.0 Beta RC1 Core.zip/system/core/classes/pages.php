<?php

require_once("templates.php");

class PageManager extends Templates
{
	public $connect;
	public $pageID;
	public $pageIndex;
	public $page;
	
	public function __construct()
	{
		$this->page = basename($_SERVER['SCRIPT_NAME']);
		
		$this->dir = dirname($_SERVER['SCRIPT_NAME']);
		
		if(isset($_REQUEST['page']))
		{
			$this->pageIndex = stripslashes($_REQUEST['page']);
		}
		else
		{
			if($_SERVER['REQUEST_URI'] == '/' && isset($_SERVER['QUERY_STRING']))
			{
				$this->pageIndex = 'index';
			}
			else
			{
				$this->pageIndex = 'dashboard';
			}
		}
		
		$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
		
		$this->loadPage($this->pageIndex);
	}
	
	public function loadPage($pageIndex)
	{
		if($pageIndex)
		{
			$query = "SELECT * FROM pages WHERE isEnabled='1'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($page = mysqli_fetch_assoc($result))
				{
					$_SESSION['page'] = $page;
					
					return $_SESSION['page'];
				}
			}
			else
			{
				echo "<div class='systemBar error' style='display:block;'>Unable to load page data with page index $pageIndex</div>";
				exit;				
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>The page index is invalid</div>";
			exit;			
		}
	}
	
	public function checkPage($pageIndex)
	{
		if($pageIndex)
		{
			$query = "SELECT * FROM pages WHERE isEnabled='1'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($page = mysqli_fetch_assoc($result))
				{
					if($page['isLocked'] == 1)
					{
						return 0;
					}
					else
					{
						return 1;
					}
				}
			}
			else
			{
				echo "<div class='systemBar error' style='display:block;'>Unable to load page data with page index $pageIndex</div>";
				exit;				
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>The page index is invalid</div>";
			exit;			
		}		
	}
}
$pages = new PageManager;