<?php

require_once("errors.php");

class Registry extends Errors
{
	public function __construct()
	{
		$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);		
		
		if(isset($_REQUEST['registryID']))
		{
			$this->registryID = htmlspecialchars($_REQUEST['registryID']);
		}
		else
		{
			$this->registryID = 1000;
		}
		
		$this->loadRegistry($this->registryID);
	}
	
	public function loadRegistry($registryID)
	{
		if($registryID)
		{
			$query = "SELECT * FROM registry WHERE registryID='".$this->connect->real_escape_string($registryID)."'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($registry = mysqli_fetch_assoc($result))
				{
					$_SESSION['registry'] = $registry;
					
					return $_SESSION['registry'];
				}
			}
			else
			{
				echo "<div class='systemBar error' style='display:block;'>Unable to load registry with ID $registryID</div>";
				exit;					
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>Invalid registry ID $registryID</div>";
			exit;				
		}
	}
}
$registry = new Registry;