<?php

require_once("config.php");

class LicenseManager extends config
{

}
$licenseManager = new LicenseManager;