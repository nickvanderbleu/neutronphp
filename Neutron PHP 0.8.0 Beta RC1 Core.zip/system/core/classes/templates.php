<?php

require_once("config.php");

class Templates extends Config
{
	public $dir;
	
	public function __construct()
	{
		$this->dir = dirname($_SERVER['SCRIPT_NAME']);
	}
	
	public function loadTemplate($theme, $pageIndex)
	{
		if($theme && $pageIndex)
		{
			require_once($_SESSION['config']['themeDir']."/".$theme."/header.php");
			require_once($_SESSION['config']['themeDir']."/".$theme."/".$pageIndex.".php");
			require_once($_SESSION['config']['themeDir']."/".$theme."/footer.php");
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>Invalid template variables</div>";
			exit;				
		}
	}
}
$templates = new Templates;