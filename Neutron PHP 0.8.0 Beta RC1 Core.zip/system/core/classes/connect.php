<?php 

require_once("tools.php");

class ConnectionManager extends Tools
{
	public $ds = "/";
	public $file = "connect.ini";
	public $connectionType = "mysqli";
	public $dbhost = 'localhost';
	public $dbuser = 'root';
	public $dbpass = '';
	public $dbname = 'neutronphp';
	public $dbport = 3306;
	
	public function __construct()
	{
		if($this->checkFile($this->sysDir.$this->ds.$this->cfgDir."/connect.ini") == 1)
		{
			$this->parseINI($this->sysDir.$this->ds.$this->cfgDir."/connect.ini", true);
			
			return $_SESSION['connect'];
			
			$this->dbhost = $_SESSION['connect']['dbhost'];
			$this->dbuser = $_SESSION['connect']['dbuser'];
			$this->dbpass = $_SESSION['connect']['dbpass'];
			$this->dbname = $_SESSION['connect']['dbname'];
			$this->dbport = $_SESSION['connect']['dbport'];
			
			if(!isset($this->dbport))
			{
				$this->dbport = 3306;
			}
			
			$this->testConnect($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
		}
	}
		
	public function testConnect($host, $user, $pass, $dbname, $port)
	{
		if($host && $user && $dbname)
		{
			switch($this->connectionType)
			{
				case "mysqli":
					{
						if(mysqli_connect($host, $user, $pass, $dbname, $port))
						{
							return 1;
						}
						else
						{
							return 0;
						}
					}
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>The fields cannot be empty</div>";
			exit;
		}
	}
}
$connect = new ConnectionManager;