<?php session_start();

require_once("connect.php");

class Tools extends MySQLi
{
	
	public $sysDir = "system";
	public $cfgDir = "config";
	public $ds = '/';
	
	public function __construct()
	{
		$this->setConfigPath();
	}
	
	public function parseINI($file, $enableArray)
	{
		if($file)
		{
			$ini = parse_ini_file($file, $enableArray);
			
			$handle = fopen($file, 'r');
			
			if(flock($handle, LOCK_EX))
			{
				switch($enableArray)
				{
					case true:
						{
							foreach($ini as $cfg => $param)
							{
								foreach($param as $key => $value)
								{
									$_SESSION[$cfg][$key] = htmlspecialchars($value);
									
									flock($handle, LOCK_UN);
									
								}
							}
						}
					case false:
						{
							foreach($ini as $key => $value)
							{
								$_SESSION['registry'][$key] = $value;
								
								$this->$key = $value;
								
								flock($handle, LOCK_UN);
							}
						}
				}
				
				fclose($handle);
			}
			else
			{
				echo "<div class='systemBar error' style='display:block;'>There was an error locking the file $file</div>";
				exit;						
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>The file handle is invalid</div>";
			exit;			
		}
	}
	
	public function checkFile($file)
	{
		if(is_file($file) && is_readable($file))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}	
	
	public function setConfigPath()
	{
		$_SESSION['configPath'] = $_SERVER['DOCUMENT_ROOT'].$this->ds.$this->sysDir.$this->ds.$this->cfgDir;
	}
}
$tools = new Tools;