<?php

require_once("config.php");

class About extends Config
{
	public $file = "about.ini";
	public $connect;
	public $aboutID;
	
	public function __construct()
	{		
	
		if(isset($_REQUEST['aboutID']))
		{
			$this->aboutID = stripslashes($_REQUEST['aboutID']);
		}
		else
		{
			if($_SESSION['config']['configID'])
			{
				$this->aboutID = $_SESSION['config']['configID'];
			}
			else
			{
				$this->aboutID = $_SESSION['registry']['configID'];
			}
		}
			
		$this->loadAbout($this->aboutID);
	}
	
	public function loadAbout($aboutID)
	{
		if($aboutID)
		{
			if($this->checkFile($_SESSION['configPath'].$this->ds.$this->file) == 1)
			{
				$this->parseINI($_SESSION['configPath'].$this->ds.$this->file, true);
				
				return $_SESSION['about'];
			}
			else
			{
				$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);

				$query = "SELECT * FROM about WHERE aboutID='".$this->connect->real_escape_string($aboutID)."'";
				$result = $this->connect->query($query);
				if($result)
				{
					while($about = mysqli_fetch_assoc($result))
					{
						$_SESSION['about'] = $about;
					}
				}
				else
				{
					echo "<div class='system error' style='display:block;'>Unable to load About configuration profile for ID $aboutID</div>";
					exit;
				}	

			}					
		}
		else
		{
			echo "<div class='system error' style='display:block;'>Invalid about ID $aboutID</div>";
			exit;			
		}
	}
	
}
$about = new About;