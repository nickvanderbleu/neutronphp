<?php

require_once("connect.php");

class Config extends ConnectionManager
{
	public $configID;
	public $file = "config.ini";
	
	public function __construct()
	{
		if(isset($_REQUEST['configID']))
		{
			$this->configID = stripslashes($_REQUEST['configID']);
			
			$this->loadConfig($this->configID);
		}
		else
		{
			if(isset($_SESSION['registry']['defaultConfigID']))
			{
				$this->defaultConfigID = $_SESSION['registry']['defaultConfigID'];
				

			}			
			else
			{
				$this->defaultConfigID = 1000;
			}
			
			$this->loadConfig($this->defaultConfigID);
		}
	}
	
	public function loadConfig($configID)
	{
		if($configID)
		{
			if($this->checkFile($_SESSION['configPath'].$this->ds.$this->file) == 1)
			{
				$this->parseINI($_SESSION['configPath'].$this->ds.$this->file, true);
				
				return $_SESSION['config'];
			}
			else
			{
				$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
				
				$query = "SELECT * FROM config WHERE configID='".$this->connect->real_escape_string($configID)."'";
				$result = $this->connect->query($query);
				if($result)
				{
					while($config = mysqli_fetch_assoc($result))
					{
						$_SESSION['config'] = $config;
						
						return $_SESSION['config'];
					}
				}
				else
				{
					echo "<div class='system error' style='display:block;'>Unable to load configuration data for config ID $configID</div>";
					exit;
				}
			}
		}
		else
		{
					echo "<div class='system error' style='display:block;'>Invalid configuration ID $configID</div>";
					exit;
		}	
		
	}
}
$config = new Config;