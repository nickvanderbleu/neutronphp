<?php

require_once("connect.php");

class Errors extends ConnectionManager
{
	public $file = "errors.ini";
	
	public function __construct()
	{
		$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
	}
	
	public function loadError($errorID)
	{
		if($errorID)
		{
			$this->parseINI($_SESSION['configPath'].$this->ds.$this->file, true);
			
			return $_SESSION['errors'][$errorID];
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>Invalid error ID $errorID</div>";
			exit;				
		}
	}
}
$errors = new Errors;