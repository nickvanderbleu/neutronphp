<?php

require_once("classes/connect.php");
require_once("classes/errors.php");
require_once("classes/registry.php");
require_once("classes/templates.php");
require_once("classes/pages.php");
require_once("classes/about.php");
