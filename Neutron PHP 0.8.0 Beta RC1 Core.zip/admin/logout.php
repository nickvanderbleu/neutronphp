<?php session_start();

if(isset($_SESSION['user']))
{
    unset($_SESSION['user']);
    header("location:login.php?cmd=login");
}
else
{
    echo "<div class='systemBar error ' style='display:block;'>The user session is invalid</div>";
}