<!doctype html>
<html>
	<head>
		<title><?php echo $_SESSION['about']['productName'];?></title>
	</head>
	<body>
	</body>
</html>