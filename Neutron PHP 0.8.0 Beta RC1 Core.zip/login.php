<?php

require_once("system/core/classes/tools.php");

require_once("system/core/classes/config.php");

if($tools->checkFile("login.php") == 1)
{
	require_once("themes/".$_SESSION['config']['defaultTheme']."/login.php");
}
else
{
	echo "<div class='systemBar error' style='display:block;'>The login file is invalid</div>";
	exit;	
}