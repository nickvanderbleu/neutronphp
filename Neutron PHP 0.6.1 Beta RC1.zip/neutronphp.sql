/*
 Navicat Premium Dump SQL

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80030 (8.0.30)
 Source Host           : localhost:3306
 Source Schema         : neutronphp

 Target Server Type    : MySQL
 Target Server Version : 80030 (8.0.30)
 File Encoding         : 65001

 Date: 19/09/2024 16:28:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for about
-- ----------------------------
DROP TABLE IF EXISTS `about`;
CREATE TABLE `about`  (
  `aboutID` int NOT NULL COMMENT ' ',
  `productID` int NOT NULL,
  `productName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `companyName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `supportPhone` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `supportEmail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `majorVer` int NULL DEFAULT NULL,
  `minorVer` int NULL DEFAULT NULL,
  `rcVer` int NULL DEFAULT NULL,
  `securityPatch` int NULL DEFAULT NULL,
  `channel` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `subChannel` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `developers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  PRIMARY KEY (`aboutID`, `productID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for blacklist
-- ----------------------------
DROP TABLE IF EXISTS `blacklist`;
CREATE TABLE `blacklist`  (
  `blacklistID` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `host` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `ipAddress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `dateAccessed` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `isLocked` int NULL DEFAULT NULL,
  `isEnabled` int NULL DEFAULT NULL,
  `page` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `emailCode` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `loginCount` int NULL DEFAULT NULL,
  `pageIndex` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config`  (
  `configID` int NOT NULL,
  `defaultTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `securityLevel` int NULL DEFAULT NULL,
  `enableCache` int NULL DEFAULT NULL,
  `enableAdmin` int NULL DEFAULT NULL,
  `enableSite` int NULL DEFAULT NULL,
  `enableTranslation` int NULL DEFAULT NULL,
  `themeDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `assetDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `globalDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `dataDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `cacheDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `jqueryDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `adminTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `siteTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `cacheTTL` int NULL DEFAULT NULL,
  `sessionTimeoutWarning` int NULL DEFAULT NULL,
  `sessionTimeoutRedirect` int NULL DEFAULT NULL,
  `tableDisplayLimit` int NULL DEFAULT NULL,
  `jqueryTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  PRIMARY KEY (`configID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for errors
-- ----------------------------
DROP TABLE IF EXISTS `errors`;
CREATE TABLE `errors`  (
  `errorID` int NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `label` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `errorString` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `isEnabled` int NULL DEFAULT NULL,
  PRIMARY KEY (`errorID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for logs
-- ----------------------------
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs`  (
  `logID` int NOT NULL,
  `ipAddress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `host` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `page` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `pageIndex` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `errorString` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `errorStatus` int NULL DEFAULT NULL,
  `dateAccessed` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  PRIMARY KEY (`logID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pages
-- ----------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages`  (
  `pageID` int NOT NULL,
  `page` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `pageIndex` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `label` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `isLocked` int NULL DEFAULT NULL,
  `isEnabled` int NULL DEFAULT NULL,
  `noCache` int NULL DEFAULT NULL,
  PRIMARY KEY (`pageID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for registry
-- ----------------------------
DROP TABLE IF EXISTS `registry`;
CREATE TABLE `registry`  (
  `registryID` int NOT NULL,
  `enableErrors` int NULL DEFAULT NULL,
  `enableStartupErrors` int NULL DEFAULT NULL,
  `enableDisplayErrors` int NULL DEFAULT NULL,
  `enableDevMode` int NULL DEFAULT NULL,
  `defaultTimezone` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `defaultLanguage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `defaultTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  PRIMARY KEY (`registryID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for security
-- ----------------------------
DROP TABLE IF EXISTS `security`;
CREATE TABLE `security`  (
  `profileID` int NOT NULL,
  `enableMFA` int NULL DEFAULT NULL,
  `defaultSecurityPhrase` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `securityLevel` int NULL DEFAULT NULL,
  `maxUserLoginCount` int NULL DEFAULT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  PRIMARY KEY (`profileID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sites
-- ----------------------------
DROP TABLE IF EXISTS `sites`;
CREATE TABLE `sites`  (
  `siteID` int NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `label` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `companyName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `companyPhone` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `supportEmail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `isDefault` int NULL DEFAULT NULL,
  `isEnabled` int NULL DEFAULT NULL,
  `theme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `language` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  PRIMARY KEY (`siteID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
