<?php session_start();

if($_SESSION['user'])
{
	unset($_SESSION['user']);
	header("location:index.php?page=login&cmd=login");
}
else
{
	die("<div class='systemBar error' style='display:block;>Unable to locate user session</div>");
}