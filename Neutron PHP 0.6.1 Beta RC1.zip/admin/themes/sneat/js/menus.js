		$(document).ready(function(){		
			
			$(".menu .nav li").each(function(e){				
				$(this).click(function(e){				
					 e.preventDefault();
					
					$(".menu ul li").removeClass("active");
					$(this).addClass("active");							
					location.href = $(this).attr("link");
					
				});
				
				if($(".page").attr("data") == $(this).text())
				{
					$(".menu ul li").removeClass("active");
					$(this).addClass("active");					
					
				}					
			})
			
			$(".tabs table thead tr td a").each(function(){
				$(this).click(function(){
					$(".tabs table thead tr td a").removeClass("active");
					$(".page .inner").hide();
					$(this).addClass("active");
					$(".page .inner."+$(this).attr("data")).show();
					
				})
			})
			
		}).mouseup(function(e)
			{
			var container = $(".submenu");

			// if the target of the click isn't the container nor a descendant of the container
			if (!container.is(e.target) && container.has(e.target).length === 0)
			{
			container.hide();
			}
		});

function menuToggle()
{
	if($(".menu").outerWidth() == 301)
		{
			$(".menu").css("width", "61px");
			$(".menu .nav li .text").text("");			
			$(".pageWrapper").css("width", $(document).outerWidth() - '139' + 'px');
			$(".pageWrapper").css("position", "asbolute");
			$(".pageWrapper").css("left", "59px");
		}
	else
		{
			$(".menu").css("width", "300px");
			$(".menu .nav li .text").text($(".menu .nav li").attr("data"));
			$(".pageWrapper").css("width", $(document).outerWidth() - '381' + 'px');
			$(".pageWrapper").css("position", "asbolute");
			$(".pageWrapper").css("left", "301px");			
		}
}