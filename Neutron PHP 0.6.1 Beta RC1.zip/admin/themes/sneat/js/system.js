$(document).ready(function(){


	$(".systemCfg .menu li").each(function(){
		$(this).click(function(){
			if($(this).attr("link") == $(".systemCfg .content."+$(this).attr("link")).attr("data"))
			{
				$(".systemCfg .content").css("display", "none");
				
				$(".systemCfg .menu li").removeClass("active");	
				$(this).addClass("active");			
				$(".systemCfg .content."+$(this).attr("link")).css("display", "block");
				
			}
		});

	})
})

function nextStep(tabLink)
{
	$(".systemCfg.menu li").removeClass("active");
	$(".systemCfg.menu li."+tabLink).addClass("active");
	if($(".systemCfg .content").attr("data") == tabLink)
	{
		alert("success");
	}
}

function updateParam(param, value)
{	
	
	$.ajax({
		url:"../system/core/classes/system.php?cmd=updateParam&param="+param+"&value="+value,
		type:"post",
		data:{param:param, value:value},
		success:function(response)
		{
			if(response == 1)
			{
				$(".systemBar").addClass("success");
				$(".systemBar").text("Successfully updated param "+param);
				$(".systemBar").show();
			}
		},
		error:function()
		{
			$(".systemBar").addClass("error");
			$(".systemBar").text("Unable to update config parameter " + param);
			$(".systemBar").show();
		}
	})
}