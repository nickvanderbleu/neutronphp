$(document).ready(function(){
	
	$(".loginForm").position({at:"center", my:"center", of:document});
		
	$(".rememberMe").click(function(){
		if($(this).is(":checked"))
			{
				$.cookie("email", $(".email").val());
				$.cookie("password", $(".password").val());					
			}
		else
			{
				$.cookie("email", "");
				$.cookie("password", "");
				$(this).prop("checked", false);				
			}
	})
	
	if($.cookie("email") && $.cookie("password"))
	{
		$(".email").val($.cookie("email"));
		$(".password").val($.cookie("password"));
		$(".rememberMe").attr("checked", "checked");
	}
	
	

})

function login(email, password)
{
	$.ajax({
		url:"../system/core/classes/users.php?cmd=login",
		type:"post",
		data:{email:email, password:password},
		success:function(response)
		{
			if(response == 1)
			{
				location.href = 'index.php';
			}
			else
			{
				if(response == 0 || response == "")
				{
					alert("Invalid email or password");

				}
				else
				{
					alert(response);
				}
			}
		},
		error:function(xhr)
		{
			alert(xhr.message);
		}
	})
}