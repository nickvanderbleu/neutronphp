<?php

// File Version 1.0

require_once("../system/core/classes/tools.php");

if($tools->checkFile("../".$tools->sysDir."/init.php") == 1)
{
	require_once("../".$tools->sysDir."/init.php");
}
else
{
	echo "<div class='systemBar error' style='display:block;'>The initialization file is invalid or missing</div>";
	exit;	
}