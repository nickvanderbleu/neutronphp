<?php

require_once("config.php");

class Security extends Config
{
    public $blacklistID;
    public $pageIndex;
    public $ipAddress;
    public $pageID;
    public $totalPages;
    public $pages;    
    public $page;
    public $connect;
    public $profileID;
    public $defaultSecurityPhrase = "Default";
    public $token;
    public $securityLevel;
    public $file = 'security.ini';
    
    public function __construct()
    {
        $this->page = basename($_SERVER['SCRIPT_NAME']);
        
        $this->pageIndex = isset($_REQUEST['page']) ? htmlspecialchars($_REQUEST['page'], ENT_QUOTES, 'UTF-8') : 'index';
        $this->pageID = isset($_REQUEST['pageID']) ? (int)$_REQUEST['pageID'] : 1;
        $this->profileID = isset($_REQUEST['profileID']) ? htmlspecialchars($_REQUEST['profileID'], ENT_QUOTES, 'UTF-8') : htmlspecialchars($_SESSION['config']['configID'], ENT_QUOTES, 'UTF-8');
        $this->blacklistID = isset($_REQUEST['blacklistID']) ? htmlspecialchars($_REQUEST['id'], ENT_QUOTES, 'UTF-8') : mt_rand(1000000, 9999999999);
        $this->securityLevel = $_SESSION['config']['securityLevel'];
        
		$this->connect = new MySQLi($_SESSION['connect']['dbhost'], $_SESSION['connect']['dbuser'], $_SESSION['connect']['dbpass'], $_SESSION['connect']['dbname'], $_SESSION['connect']['dbport']);
        
        $this->systemID = isset($_REQUEST['systemID']) ? htmlspecialchars($_REQUEST['systemID'], ENT_QUOTES, 'UTF-8') : md5($this->genSecurityToken() . $this->defaultSecurityPhrase);
        $this->ipAddress = $this->getClientIP();
        
        $this->updateBlacklist($this->blacklistID, $this->ipAddress, htmlspecialchars($this->pageIndex, ENT_QUOTES, 'UTF-8'));
        $this->loadSecurityProfile($this->profileID);
        $this->updateSecurityToken($this->systemID);
    }
	
	public function loadIPList($tableDisplayLimit)
	{
    	$offset = (((int)$this->pageID - 1) * $tableDisplayLimit);
		
		$query = "SELECT * FROM blacklist";
		$result = $this->connect->query($query);
		$totalRows = mysqli_num_rows($result);
  		$this->totalPages = ceil($totalRows / $tableDisplayLimit) - 2;		
		$query2 ="SELECT * FROM blacklist LIMIT ".((int)$offset).",".$tableDisplayLimit;
		$result2 = $this->connect->query($query2);
		if($result2)
		{
			while($blacklist = mysqli_fetch_assoc($result2))
			{
				?>
					<tr>
						<td><?php echo $blacklist['blacklistID'];?></td>
						<td><?php echo $blacklist['host'];?></td>
						<td><?php echo $blacklist['ipAddress'];?></td>
						<td><?php echo $blacklist['dateAccessed'];?></td>
						<td><?php echo $blacklist['page'];?></td>						
						<td><?php echo $blacklist['pageIndex'];?></td>	
						
						<td><?php echo $blacklist['loginCount'];?><a href='javascript:void(0)'><i class='fa fa-refresh'></i></a></td>						
						<td>
						<?php
								if($blacklist['isLocked'] == 1)
								{
									?>							
										<div class='label error'>Yes</div>
									<?php
								}
								else
								{
									?>							
										<div class='label success'>No</div>		
									<?php
								}				
						?>
						</td>
						<td>

							<a href='javascript:void(0)' onclick='deleteIP($(this).attr("data"))' data='<?php echo $blacklist['ipAddress'];?>'><i class='fa fa-trash'></i></a>
							<?php
								if($blacklist['isLocked'] == 1)
								{
									?>							
										<a href='javascript:void(0)' onclick='unlockIP($(this).attr("data"))' data='<?php echo $blacklist['ipAddress'];?>'><i class='fa fa-unlock'></i></a>		
									<?php
								}
								else
								{
									?>							
										<a href='javascript:void(0)' onclick='lockIP($(this).attr("data"))' data='<?php echo $blacklist['ipAddress'];?>'><i class='fa fa-lock'></i></a>		
									<?php
								}
							?>							
						</td>
					</tr>
				<?php
			}			
		}
		else
		{
			die("<div class='systemBar error' style='display:block;'>Unable to load site data</div>");
		}		
	}		
	
	public function loadLogs($limit)
	{
    	$offset = ($this->pageID * $limit);
		
		$query = "SELECT * FROM logs";
		$result = $this->connect->query($query);
		$totalRows = mysqli_num_rows($result);
  		$this->totalPages = ceil($totalRows / $limit) ;		
		$query2 ="SELECT * FROM logs LIMIT ".((int)$offset).",".$limit;
		$result2 = $this->connect->query($query2);
		if($result2)
		{
			while($logs = mysqli_fetch_assoc($result2))
			{
				?>
					<tr>
						<td><?php echo $logs['logID'];?></td>
						<td><?php echo $logs['host'];?></td>
						<td><?php echo $logs['ipAddress'];?></td>
						<td style='width:300px'><?php echo $logs['dateAccessed'];?></td>
						<td><?php echo $logs['pageIndex'];?></td>												
						<td><?php echo $logs['errorString'];?></td>
						<td>
							<div class='label error'>No Action</div>
						</td>
					</tr>
				<?php
			}			
		}
		else
		{
			die("<div class='systemBar error' style='display:block;'>Unable to load site data</div>");
		}		
	}	
    
    public function paginate($class, $pageIndex)
    {
        ?>
            <a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=1'>First</a>
            <style>
                .disabled {
                    color: #eee;
                    border: solid 1px #eee;
                }
                .disabled:hover {
                    cursor: default;
                    background: #fff;
                    color: #eee;
                    border: solid 1px #eee;
                }                
            </style>
        <?php
        
        if ($_REQUEST['pageID'] == 1) {
            ?>
                <a class='<?php echo $class;?> disabled' href='javascript:void(0)'>Prev</a>    
            <?php
        } else {
            ?>
                <a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo (int)$_REQUEST['pageID'] - 1;?>'>Prev</a>    
            <?php            
        }        
        
        ?>
            <a class='active <?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo (int)$_REQUEST['pageID'];?>'><?php echo (int)$_REQUEST['pageID'];?></a>
        <?php        
        if ($_REQUEST['pageID'] >= $this->totalPages + 2) {
            ?>
                <a class='<?php echo $class;?> disabled' href='javascript:void(0)'>Next</a>    
            <?php
        } else {
            ?>
                <a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo (int)$_REQUEST['pageID'] + 1;?>'>Next</a>    
            <?php            
        }    

        ?>
            <a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $this->totalPages + 2;?>'>Last</a>
        <?php            
    }            
    
	public function lockByIP($ipAddress)
	{
		if($ipAddress)
		{
			$query = "UPDATE blacklist SET isLocked='1' WHERE ipAddress='".$ipAddress."'";
			$result = $this->connect->query($query);
			if($result)
			{
				return 1;
			}
			else
			{
				echo "Unable to update blacklist";
			}
		}
		else
		{
			echo "Invalid IP address";
		}
	}
	
	
    public function updateSecurityToken($token)
    {
        $token = md5($token);
        
        if (isset($token)) {
            $query = "UPDATE security SET token='" . $this->connect->real_escape_string($token) . "' WHERE defaultSecurityPhrase='" . $this->connect->real_escape_string($this->defaultSecurityPhrase) . "'";
            $result = $this->connect->query($query);
            if ($result) {
                $this->token = $token;    
            } else {
                echo "<div class='systemBar error' style='display:block;'>Unable to update system token</div>";
                exit;
            }            
        } else {
            echo "<div class='systemBar error' style='display:block;'>Invalid system token</div>";
            exit;
        }
    }
    
	public function createLog($host, $ipAddress, $page, $pageIndex, $errorString, $errorStatus)
	{
		$date = date('Y-m-d H:i:s A T');
		
		$logID = mt_rand(1000001, 9999999);
		
		$query = "INSERT INTO logs (logID, host, ipAddress, dateAccessed, errorString, errorStatus, pageIndex) VALUES('".$this->connect->real_escape_string($logID)."', '".$this->connect->real_escape_string($host)."', '".$this->connect->real_escape_string($ipAddress)."', '".$this->connect->real_escape_string($date)."', '".$this->connect->real_escape_string($errorString)."', '".$this->connect->real_escape_string($errorStatus)."', '".$this->connect->real_escape_string($pageIndex)."' )";
		$result = $this->connect->query($query);
		if($result)
		{
			return 1;
		}
		else
		{
			die("<div class='systemBar error' style='display:block;'>Unable to add log $logID to logs</div>");
		}
	}	
	
    public function genSecurityToken()
    {
        $characters = '0123456789abcdefghjklmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ!@#$%^&*()';
        $token = '';
        for ($i = 0; $i < 32; $i++) {
            $token .= $characters[mt_rand(0, strlen($characters) - 1)];
        }
        return $token;
    }
    
    public function getClientIP()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }
    
	public function updateBlacklist($blacklistID, $ipAddress, $pageIndex)
	{
		$date = date('Y-m-d H:i:s A T');
		
		$query = "SELECT * FROM blacklist WHERE ipAddress='".$this->connect->real_escape_string($ipAddress)."'";
		$result = $this->connect->query($query);
		if($result)
		{
			if(mysqli_num_rows($result) == 0)
			{
				$query2 = "INSERT INTO blacklist (blacklistID, ipAddress, host, dateAccessed, page, pageIndex, isLocked, loginCount) VALUES('".$this->connect->real_escape_string($blacklistID)."', '".$this->connect->real_escape_string($ipAddress)."', '".$this->connect->real_escape_string($_SERVER['HTTP_HOST'])."', '".$this->connect->real_escape_string($date)."', '".$this->connect->real_escape_string($this->page)."', '".$this->connect->real_escape_string($pageIndex)."', '0', '1')";
				$result2 = $this->connect->query($query2);
				if($result2)
				{
					return 1;
				}
				else
				{
					die("<div class='systemBar error' style='display:block;'>Unable to update blacklist</div>");
				}			
			}
			else
			{
				$query3 = "UPDATE blacklist SET host='".$this->connect->real_escape_string($_SERVER['HTTP_HOST'])."', dateAccessed='".$this->connect->real_escape_string($date)."', page='".$this->connect->real_escape_string($this->page)."', pageIndex='".$this->connect->real_escape_string($pageIndex)."', loginCount=loginCount+1 WHERE ipAddress='".$ipAddress."'";
				$result3 = $this->connect->query($query3);
				if($result3)
				{
					return 1;
				}
				else
				{
					die("<div class='systemBar error' style='display:block;'>Unable to update blacklist</div>");
				}					
			
			}
		}
		else
		{
			die("<div class='systemBar error' style='display:block;'>Unable to load blacklist</div>");
		}
	}
	
	public function checkBlacklist($ipAddress)
	{
		$query = "SELECT * FROM blacklist WHERE ipAddress='".$this->connect->real_escape_string($ipAddress)."'";
		$result = $this->connect->query($query);
		if($result)
		{
			while($blacklist = mysqli_fetch_assoc($result))
			{
				if($blacklist['isLocked'] == true)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to check blacklist with IP address ".$ipAddress."</div>");
		}
	}	
	
	public function loadSecurityProfile($profileID)
	{				
		if($profileID)
		{
			$query = "SELECT * FROM security WHERE profileID='".$this->connect->real_escape_string($profileID)."'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($security = mysqli_fetch_assoc($result))
				{
					$_SESSION['security'] = $security;
				}
			}
			else
			{
				die("<div class='systemBar error' style='display:block;'>Unable to load security profile $profileID</div>");
			}			
		}
		else
		{
			die("<div class='systemBar error' style='display:block;'>Invalid security profile ID</div>");
		}
	}
}
$security = new Security;
?>