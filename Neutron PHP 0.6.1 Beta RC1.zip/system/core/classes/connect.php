<?php

require_once("registry.php");

class Connect extends Registry
{
	public $connectionType = 'mysqli';
	public $file = "connect.ini";
	public $connect;
	public $dbhost;
	public $dbuser;
	public $dbpass;
	public $dbname;
	public $dbport;
	
	public function __construct()
	{
		
		if($this->checkFile($_SESSION['configPath'].$this->ds.$this->file) == 1)
		{
			$this->parseINI($_SESSION['configPath'].$this->ds.$this->file, true);
			
			if(!isset($this->port))
			{
				$this->port = 3306;
			}
			
			$this->testConnect($this->connectionType);
		}
	}
	
	public function testConnect($connectionType)
	{
		switch($connectionType)
		{
			case "mysqli":
			{
				if(mysqli_connect($_SESSION['connect']['dbhost'], $_SESSION['connect']['dbuser'], $_SESSION['connect']['dbpass'], $_SESSION['connect']['dbname'], $_SESSION['connect']['dbport']))
				{
					return 1;
				}
				else
				{
					return 0;
				}
				break;
			}
		}
	}
}
$connect = new Connect;