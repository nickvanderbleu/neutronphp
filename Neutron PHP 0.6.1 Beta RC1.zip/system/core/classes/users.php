<?php 

require_once("security.php");

class UserManager extends Security
{
	public $connect;
	public $ipAddress;
	
	public function __construct()
	{
		
		$this->ipAddress = $this->getClientIP();
				
		if(isset($_REQUEST['page']))
		{
			$this->pageIndex = stripslashes($_REQUEST['page']);
		}
		else
		{
			$this->pageIndex = 'index';
		}
		
		if(isset($_REQUEST['pageID']))
		{
			$this->pageID = stripslashes($_REQUEST['pageID']);
		}
		else
		{
			$this->pageID = 1;
		}
				
		
		$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
				
		if(isset($_REQUEST['cmd']))
		{
			switch($_REQUEST['cmd'])
			{
				case "login":
					{
						$this->login($_REQUEST['email'], $_REQUEST['password']);
						break;
					}
					
				case "emailSignUp":
					{
						$this->emailSignUp($_REQUEST['email']);
						break;
					}
				case "resetLoginCount":
					{
						$this->resetLoginCount($_REQUEST['accountID']);
						break;
					}
				case "deleteUser":
					{
						$this->deleteUser($_REQUEST['accountID']);
					}
				case "updateAccountLock":
					{
						$this->updateAccountLock($_REQUEST['accountID'], $_REQUEST['value']);
						break;
					}
			}
		}
		
		$this->ipAddress = $this->getClientIP();
	}
	
	public function updateAccountLock($accountID, $value)
	{
		$query = "UPDATE users SET isLocked='".$this->connect->real_escape_string($value)."' WHERE accountID='".$this->connect->real_escape_string($accountID)."'";
		$result = $this->connect->query($query);
		if($result)
		{
			return 1;
		}
		else
		{
			echo "Unable to update user account lock for user $accountID";
		}
	}
	
	public function resetLoginCount($accountID)
	{
		$query = "update users set loginCount='0' where accountID='".$this->connect->real_escape_string($accountID)."';";
		$result = $this->connect->query($query);
		if($result)
		{
			echo 1;
		}
		else
		{
			echo "Unable to update user ".$accountID;
		}
	}
	
	public function deleteUser($accountID)
	{
		$query = "DELETE FROM users WHERE accountID='".$this->connect->real_escape_string($accountID)."'";
		$result = $this->connect->query($query);
		if($result)
		{
			echo 1;
		}
		else
		{
			echo "Unable to delete user $accountID";
		}		
	}
	
	public function loadUsers($limit)
	{
    	$offset = (((int)$this->pageID - 1) * $limit);
		
		$query = "SELECT * FROM users";
		$result = $this->connect->query($query);
		$totalRows = mysqli_num_rows($result);
  		$this->totalPages = ceil($totalRows / $limit) - 2 ;		
		$query2 ="SELECT * FROM users LIMIT ".((int)$offset).",".$limit;
		$result2 = $this->connect->query($query2);
		if($result2)
		{
			while($users = mysqli_fetch_assoc($result2))
			{
				?>
					<tr>
						<td><?php echo $users['accountID'];?></td>
						<td><?php echo $users['firstName'];?></td>
						<td><?php echo $users['lastName'];?></td>
						<td><?php echo $users['email'];?></td>						
						<td>
							<?php
								switch($users['acctType'])
								{
									case 0:
										{
											echo "Admin";
											break;
										}
									case 1:
										{
											echo "Moderator";
											break;
										}
									case 2:
										{
											echo "Standard";
											break;
										}
								}
							?>
						</td>	
						<td><?php echo $users['dateAccessed'];?></td>
						<td style='line-height: 50px;'><div class='loginCount' style='position:relative;float:left;'><?php echo $users['loginCount'];?></div><a class='resetLoginCount' href='javascript:void(0)' style='position:relative;float:right;display:block;right:15px;top:7px;' data='<?php echo $users['accountID'];?>' onclick='resetLoginCount($(this).attr("data"));'><i class='fa fa-refresh'></i></a></td>
						<td>
							<?php
								if($users['isLocked'] == 0)
								{
									
									?>
										<div class='success label'>No</div>
									<?php									
								}
								else
								{
									?>
										<div class='label error'>Yes/div>
									<?php
								}				
							?>
						</td>
						<td style='text-indent:0px;margin-left:0px;'>
							<?php
								if($users['isLocked'] == 1)
								{
									?>
										<a href='javascript:void(0)' title='Unlock account <?php echo $users['accountID'];?>' class='lock' data='<?php echo $users['accountID'];?>' onclick='updateAccountLock($(this).attr("data"), 0);'><i class='fa fa-unlock'></i></a>
									<?php
								}
								else
								{
									?>
										<a href='javascript:void(0)' title='Lock account <?php echo $users['accountID'];?>' class='unlock' data='<?php echo $users['accountID'];?>' onclick='updateAccountLock($(this).attr("data"), 1);'><i class='fa fa-lock'></i></a>
									<?php
								}				
							?>
							<a href='javascript:void(0)' class='deleteUser' data='<?php echo $users['accountID'];?>' title='Delete user <?php echo $users['accountID'];?>' onclick='deleteUser($(this).attr("data"))'><i class='fa fa-trash'></i></a>
							<a href='javascript:void(0)' class='editUser' data='<?php echo $users['accountID'];?>' onclick='editUser($(this).attr("data"))' title='Edit user <?php echo $users['accountID'];?>'><i class='fa fa-pencil'></i></a>
							<a href='javascript:void(0)' data='<?php echo $users['email'];?>' onclick='sendActivationEmail($(this).attr("data"))' title='Send verification email to user <?php echo $users['accountID'];?>'><i class='fa fa-envelope-o'></i></a>
							<a href='javascript:void(0)' title='Change password for user <?php echo $users['accountID'];?>'><i class='fa fa-key'></i></a>
						</td>
					</tr>
				<?php
			}			
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to load site data</div>");
		}
	}	
	
	public function loadProfile($accountID)
	{
		if(isset($accountID))
		{
			$query = "SELECT * FROM profiles WHERE accountID='".$this->connect->real_escape_string($accountID)."'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($profile = mysqli_fetch_assoc($result))
				{
					$_SESSION['user']['profile'] = $profile;
					
					$this->updateLoginCount($accountID);
				}
			}
			else
			{
				echo "Unable to load account profile $accountID";
			}
				
		}
		else
		{
			echo "The account ID is invalid";
		}
	}
	
	public function updateLoginCount($accountID)
	{
		$query = "update users set loginCount=loginCount+1 where accountID='".$this->connect->real_escape_string($accountID)."'";
		$result = $this->connect->query($query);
		if($result)
		{
			echo 1;
		}
		else
		{
			echo "Unable to update login count for user $accountID";
			
		}		
	}
	
	public function login($email, $password)
	{
		if($email && $password)
		{
			$password = md5($password);
			
			$date = date('Y-m-d H:i:s A T');
			
			$query = "SELECT * FROM users WHERE email='".$this->connect->real_escape_string($email)."' AND password='".$this->connect->real_escape_string($password)."'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($user = mysqli_fetch_assoc($result))
				{
					switch($user['isLocked'])
					{
						case 0:
						{
								switch($user['status'])
								{
									case 0:
									{
										echo "Your acocunt is inactive";
										break;
									}
									case 1:
									{
										if($_SESSION['config']['enableMFA'] == 1)
										{
											echo "Expirimental";
											break;
										}
										else
										{
											$_SESSION['user'] = $user;;
											
											$this->loadProfile($user['accountID']);
											
											break;
										}
										
									}
									case 2:
									{
										echo "Your account is pending activation";
										break;
									}
									case 3:
									{
										echo "Your acocunt is suspended";
										break;
									}
									
								}
								break;								

						}
						case 1:
						{
							echo "Your account is locked";
							break;
						}
						
					}
				}
			}
			else
			{
				$query2 = "SELECT * FROM blacklist WHERE ipAddress='".$this->ipAddress."'";
				$result2 = $this->connect->query($query2);
				if($result2)
				{
					while($blacklist = mysqli_fetch_assoc($result2))
					{
						if($blacklist['isLocked'] == 0)
						{
							$loginCount = $blacklist['loginCount'];
							$loginCount++;
							
							if($loginCount % $_SESSION['config']['maxLoginCount'] == 0)
							{
								$this->lockByIP($this->ipAddress);
								
								echo "Your IP address has been locked";
								exit;
							}
							else
							{
								echo "Unable to load user data with provided information";
							}							
						}
						else
						{
							echo "Your IP address is locked";
							exit;
						}
					}
				}
				else
				{
					echo "Unable to load blacklist data";
				} 			
			}
		}
		else
		{
			$query = "SELECT * FROM blacklist WHERE ipAddress='".$this->ipAddress."'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($blacklist = mysqli_fetch_assoc($result))
				{
					if($blacklist['isLocked'] == 0)
					{
						$loginCount = $blacklist['loginCount'];
						$loginCount++;
						
						if($loginCount % $_SESSION['config']['maxLoginCount'] == 0)
						{
							$this->lockByIP($this->ipAddress);
							
							echo "Your IP address has been locked";
							exit;
						}
						else
						{
							echo "Invalid email or password";
						}							
					}
					else
					{
						echo "Your IP address is locked";
						exit;
					}
				}
			}
			else
			{
				echo "Unable to load blacklist data";
			}
		}
	}
	
	public function emailSignUp($email)
	{
		$newsletterID = mt_rand(10000, 999999999);
		
		$query = "SELECT * FROM newsletter WHERE email='".$email."'";
		$result = $this->connect->query($query);
		if($result)
		{
			if(connect_num_rows($result) == 0)
			{
				$query2 = "INSERT INTO newsletter (newsletterID, email, optIn) VALUES('".$newsletterID."', '".$email."', '1')";
				$result2 = $this->connect->query($query2);
				if($result2)
				{
					echo 1;
				}
				else
				{
					echo "Unable to add your email to the newsletter";
				}
				
			}
			else
			{
				echo "That email already exists";
			}
		}
		else
		{
			echo "Unable to load user data";
		}
	}
}
$user = new UserManager;