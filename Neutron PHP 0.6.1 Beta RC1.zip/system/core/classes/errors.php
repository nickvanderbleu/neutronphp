<?php

require_once("connect.php");

class Errors extends Connect
{
	public $file = "errors.ini";
	
	public function __construct()
	{
		$this->loadErrors($_SESSION['configPath']."/".$this->file);
	}
	
	public function loadErrors($file)
	{
		if($this->checkFile($file) == 1)
		{
			$this->parseINI($file, true);
			
			return $_SESSION['errors'];
		}
		else
		{
			echo "<div class='system error' style='display:block;'>The error configuration file is invalid</div>";
			exit;
		}
	}
		
	public function loadError($errorID)
	{
		if($this->checkFile($_SESSION['configPath']."/".$this->file) == 1)
		{
			$this->parseINI($_SESSION['configPath']."/".$this->file, true);
			
			return $_SESSION['errors'][$errorID];
		}
		else
		{
			$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);

			$query = "SELECT * FROM errors WHERE errorID='".$this->connect->real_escape_string($errorID)."'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($error = mysqli_fetch_assoc($result))
				{
					$_SESSION['errors'][$errorID] = $error[$errorID];
				}
			}
			else
			{
				echo "<div class='system error' style='display:block;'>Unable to load About configuration profile for ID $aboutID</div>";
				exit;
			}	
		}	
	}
}
$errors = new Errors;