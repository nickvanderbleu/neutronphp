<?php

require_once("security.php");

class LicenseManager extends Security
{
    public $remoteHost = 'localhost';
    public $remoteUser = 'root';
    public $remotePass = 'Decepticon@#1';
    public $remoteDB = 'neutronphp';
    public $remotePort = 3306;
    public $file = 'manifest.ini';
    private $licenseData;
    private $isDemo;

    public function __construct()
    {
        $this->connect = new MySQLi($this->remoteHost, $this->remoteUser, $this->remotePass, $this->remoteDB, $this->remotePort);
		
    }
public function loadLicense($email)
{
    $query = "SELECT * FROM licenses WHERE contactEmail='".$this->connect->real_escape_string($email)."'";
    $result = $this->connect->query($query);

    if ($result) {

        while ($license = mysqli_fetch_assoc($result)) {
            ?>
            <div class='license' style='border:solid 1px #ddd;padding:10px;width:300px;height:125px;display:block;float:left;position:relative;margin-right:10px;margin-bottom:10px;'>
                <span style='margin-bottom:10px;'>App Name: <?php echo $license['appName'];?></span>
                <br>
                <span style='margin-bottom:10px;'>Issue to: <?php echo $license['issueTo'];?></span>
                <br>
                <span style='margin-bottom:10px;'>Key: <?php echo $license['licenseKey'];?></span>
                <br><br>
                <?php
					if($license['isDemo'] == 1)
					{
						?><div style='position:Relative;top:-10px;float:left;width:100%;display:block;'><?php $this->checkLicenseKey($license['licenseKey']); ?></div><?php
					}
					else
					{
						if($license['appName'] == 'Neutron PHP')
						{
						?>
							<a href='javascript:void(0)' class='button'>More Info</a>
						<?php							
						}
						else
						{
						?>
							<a href='javascript:void(0)' class='button'>More Info</a>
							<a href='/apps/<?php echo $license['appPath'];?>' class='button'>Launch</a>
						<?php							
						}
					}
						
				?>				
            </div>
            <?php
        }
    } else {
        echo "<div class='systemBar error' style='display:block;'>Unable to load license data</div>";
        exit;
    }
}

    private function checkLicenseKey($licenseKey)
    {
        $query = "SELECT * FROM licenses WHERE licenseKey='" . $this->connect->real_escape_string($licenseKey) . "'";
        $result = $this->connect->query($query);
        if ($result) {
            if ($result->num_rows > 0) {
                $this->licenseData = $result->fetch_assoc();
                if (!$this->licenseData['isEnabled']) {
                    echo "<div class='systemBar error' style='display:block;'>License key is not enabled</div>";
                }

                $this->isDemo = $this->checkIsDemo($this->licenseData['demoStartDate']);
                $this->checkDemoPeriod($this->licenseData['demoStartDate']);
            } else {
                echo "<div class='systemBar error' style='display:block;'>Unable to load license data</div>";
            }
        } else {
            echo "<div class='systemBar error' style='display:block;'>Unable to load license data</div>";
        }
    }

    private function checkIsDemo($demoStartDate)
    {
        $currentDate = new DateTime();
        $demoStartDate = new DateTime($demoStartDate);
        return $currentDate < $demoStartDate;
    }

    private function checkDemoPeriod($demoStartDate)
    {
        $currentDate = new DateTime();
        $demoStartDate = new DateTime($demoStartDate);
        $interval = $currentDate->diff($demoStartDate);

        if ($interval->days > 30) {
            echo "<div class='systemBar-mini error' style='display:block;background:#FFEEEE;color:red;'>Demo period has expired</div>";
        }
    }

    public function getLicenseData()
    {
        return $this->licenseData;
    }

    public function isDemo()
    {
        return $this->isDemo;
    }

    private function checkConnection()
    {
        if (mysqli_connect($this->remoteHost, $this->remoteUser, $this->remotePass, $this->remoteDB, $this->remotePort)) {
            return 1;
        } else {
            return 0;
        }
    }
}

// Usage example:
$licenseManager = new LicenseManager;

?>