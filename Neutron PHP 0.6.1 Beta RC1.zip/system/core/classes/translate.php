<?php

require_once("languages.php");

class Translate extends Languages
{
	public function __construct()
	{
		
	}
	
	public function loadTranslation($language, $pageIndex)
	{
		if($pageIndex)
		{
			if($this->checkFile("system/languages/".$language.$this->ds.$_SESSION['config']['themeDir'].$this->ds.$_SESSION['config']['defaultTheme'].$this->ds.$pageIndex.".php") == 1)
			{
				require_once("system/languages/".$language.$this->ds.$_SESSION['config']['themeDir'].$this->ds.$_SESSION['config']['defaultTheme'].$this->ds."header.php");
				require_once("system/languages/".$language.$this->ds.$_SESSION['config']['themeDir'].$this->ds.$_SESSION['config']['defaultTheme'].$this->ds.$pageIndex.".php");
				require_once("system/languages/".$language.$this->ds.$_SESSION['config']['themeDir'].$this->ds.$_SESSION['config']['defaultTheme'].$this->ds."footer.php");
			}
			else
			{
				echo "<div class='systemBar error' style='display:block;' >The language translation template is invalid</div>";
				exit;
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>Invalid page index</div>";
			exit;
		}
	}
}
$translate = new Translate;