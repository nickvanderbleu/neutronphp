<?php session_start();

class URLHandler extends MySQLi
{
	public $ds = '/';
	public $page;
	public $pageIndex;
	public $domain;
	
	public function __construct()
	{
		$this->page = basename($_SERVER['SCRIPT_NAME']);
		
		if(isset($_REQUEST['page']))
		{
			$this->pageIndex = stripslashes($_REQUEST['page']);
		}
		else
		{
			if($_SERVER['REQUEST_URI'] == '/' || $_SERVER['REQUEST_URI'] == '/' && isset($_SERVER['QUERY_STRING']))
			{
				$this->pageIndex = 'index';
			}
			else
			{
				$this->pageIndex = 'dashboard';
			}
		}
		
		$this->domain = stripslashes($_SERVER['HTTP_HOST']);
		
	}
	
	
}
$url = new URLHandler;