<?php

require_once("config.php");

class Messages extends Config
{
	public function __construct()
	{
		$this->connect = new Mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
	}
	
	public function loadMessages($limit)
	{
		$query = "SELECT * FROM messages LIMIT $limit";
		$result = $this->connect->query($query);
		if($result)
		{
			while($messages = mysqli_fetch_assoc($result))
			{
				?>
						<a class='link' href='index.php?page=messages&messageID=<?php echo $messages['messageID'];?>'>
							<div class='name' style='position:relative;float:left;padding:10px 12px;border-radius:100%;border:solid 1px #ddd;margin:10px;'>
								<?php echo substr($messages['fromFirstName'], 0, 1).substr($messages['fromLastName'], 0, 1);?>
							</div>
							<div class='info' style='position:relative;top:10px;'>
							<div class='subject'><?php echo $messages['subject'];?></div>
							<div class='fromAcct'>from <?php echo $messages['fromFirstName']." ".$messages['fromLastName'];?></div>
							</div>
							<div class='date' style='position:absolute;top:5px;right:5px;font-size:11px;'>09/08/2023 04:01 AM</div>
						</a>
				<?php				
			}
		}
		else
		{
			echo "<div class='system error' style='display:block;'>Unable to load messages</div>";
			exit;
		}
	}
}
$messages = new Messages;