<?php

require_once("pages.php");

class Templates extends Pages
{
	public $dir;
	
	public function __construct()
	{
		$this->dir = substr(dirname($_SERVER['SCRIPT_NAME']), 1);
	}
	
	public function loadTemplate($theme, $pageIndex)
	{
		if($pageIndex)
		{
			require_once($_SESSION['config']['themeDir'].$this->ds.$theme.$this->ds."header.php");
			require_once($_SESSION['config']['themeDir'].$this->ds.$theme.$this->ds.$pageIndex.".php");
			require_once($_SESSION['config']['themeDir'].$this->ds.$theme.$this->ds."footer.php");	
		}
		else
		{
			die("<div class='systemBar error' style='display:block;' data='002'>".$this->loadError('002')."</div>");
		}
	}
}
$templates = new Templates;