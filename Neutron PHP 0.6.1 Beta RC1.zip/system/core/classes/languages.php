<?php

require_once("config.php");

class Languages extends Config
{
	public $defaultLanguage = 'en_us';
	
	public function __construct()
	{
		if(isset($_REQUEST['language']))
		{
			$this->defaultLanguage = stripslashes($_REQUEST['language']);
		}
		else
		{
			if(isset($_SESSION['config']['defaultLanguage']))		
			{
				$this->defaultLanguage = $_SESSION['config']['defaultLanguage'];
			}
			else
			{
				$this->defaultLanguage = $_SESSION['registry']['defaultLanguage'];
			}
				
		}	
		
	}
	
}
$languages = new Languages;