<?php

require_once("config.php");

class Stats extends Config
{
	public $mysqli;
	
	public function __construct()
	{
		$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
		
		
	}
	
	public function updateHitCounter()
	{
		$query = "UPDATE stats SET hitCounter=hitCounter+1";
		$result = $this->connect->query($query);
		if($result)
		{
			return 1;
		}
		else
		{
			echo "<div class='system error' style='display:block;'>Unable to update hit counter</div>";
			exit;
		}
	}
	
	public function countUsers()
	{
		$query = "SELECT * FROM users";
		$result = $this->connect->query($query);
		if($result)
		{
			echo mysqli_num_rows($result);
		}
		else
		{
			echo 0;
		}
	}	
	
	public function getConversion($totalUsers, $totalVisitors)
	{
		$conversion = $totalUsers / $totalVisitors * 100;
		
		return $conversion;
	}
	
	public function getHitCounter()
	{
		$query = "SELECT * FROM stats";
		$result = $this->connect->query($query);
		if($result)
		{
			while($stats = mysqli_fetch_assoc($result))
			{
				echo $stats['hitCounter'];
			}
		}
		else
		{
			echo 0;
		}
	}	

	public function loadOpenCarts()
	{
		$query = "SELECT * FROM carts WHERE isOpen='1'";
		$result = $this->connect->query($query);
		if($result)
		{
			while($carts = mysqli_fetch_assoc($result))
			{
				echo mysqli_num_rows($result);
			}
		}
		else
		{
			echo "Unable to count blogs";
		}
	}	
	
	public function loadBlogCount()
	{
		$query = "SELECT * FROM blogs";
		$result = $this->connect->query($query);
		if($result)
		{
			while($blogs = mysqli_fetch_assoc($result))
			{
				echo mysqli_num_rows($result);
			}
		}
		else
		{
			echo "Unable to count blogs";
		}
	}
	
	public function loadConversion()
	{
		$query = "SELECT * FROM users";
		$result = $this->connect->query($query);
		if($result)
		{
			$users = mysqli_num_rows($result);
			
			$query2 = "SELECT * FROM stats";
			$result2 = $this->connect->query($query2);
			if($result2)
			{
				while($stats = mysqli_fetch_assoc($result2))
				{
					echo round($users / $stats['hitCounter'] * 100, 2);
				}
			}
			else
			{
				echo "Unable to load stats";
			}
			
		}
		else
		{
			echo "Unable to load conversion metrics";
		}
	}
	
}
$stats = new Stats;