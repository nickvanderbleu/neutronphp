<?php 

require_once("urlHandler.php");

class Tools extends URLHandler
{
	public $ds = '/';
	public $sysDir = "system";
	public $cfgDir = "config";

	public function __construct()
	{
		$this->setConfigPath();
	}
	
	public function setConfigPath()
	{
		$_SESSION['configPath'] = $_SERVER['DOCUMENT_ROOT'].$this->ds.$this->sysDir.$this->ds.$this->cfgDir;
	}
	
	public function parseINI($file, $enableArray)
	{
		$file = realpath($file); // Resolve to absolute path
		if($this->checkFile($file) == 1)
		{
			$fp = fopen($file, 'r');
			if (flock($fp, LOCK_SH)) { // Shared lock for reading
				$content = file_get_contents($file);
				$hash = hash('sha256', $content); // Calculate hash
				
				$ini = parse_ini_string($content, $enableArray);
				
				if($enableArray == true)
				{	
					foreach($ini as $cfg => $param)
					{
						foreach($param as $key=> $value)
						{
							$_SESSION[$cfg][$key] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); // Sanitize output
						}
					}
				}
				else
				{
					foreach($ini as $key => $value)
					{
						$_SESSION['registry'][$key] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); // Sanitize output
					}
				}
				
				// Verify hash
				if ($hash !== hash('sha256', file_get_contents($file))) {
					echo "<div class='systemBar error' style='display:block;'>The configuration file has been tampered with</div>";
					exit;
				}
				
				flock($fp, LOCK_UN); // Unlock after reading
			} else {
				echo "<div class='systemBar error' style='display:block;'>Unable to lock the configuration file</div>";
				exit;
			}
			fclose($fp);
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>The configuration file is invalid</div>";
			exit;
		}
	}

	public function checkFile($file)
	{
		if($file)
		{
			if(is_readable($file) && is_file($file))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>The file handle is invalid</div>";
			exit;
		}
	}
}
$tools = new Tools;