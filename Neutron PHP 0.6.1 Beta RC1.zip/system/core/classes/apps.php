<?php

require_once("license.php");

class AppManager extends LicenseManager
{
	public $connect;
	public $file = "manifest.ini";
	public $appDir = "apps";
	
	public function __construct()
	{
		$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
		
		$this->loadManifest();
	}
	
	public function loadManifest()
	{
		$query = "SELECT * FROM apps";
		$result = $this->connect->query($query);
		if($result)
		{
			while($apps = mysqli_fetch_assoc($result))
			{

			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>Unable to load app manifest</div>";
			exit;			
		}
		
	}
	
	public function getApps()
	{
		$query = "SELECT * FROM apps WHERE isEnabled='1'";
		$result = $this->connect->query($query);
		if($result)
		{
			while($app = mysqli_fetch_assoc($result))
			{
				?>
					<a class='button link' href='<?php echo $app['path'];?>/index.php?page=dashboard'>
						<?php echo $app['appName'];?>
					</a>
				<?php				
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>Unable to load apps</div>";
			exit;
		}	
		
	}	
	
	public function loadApps()
	{
		$query = "SELECT * FROM apps WHERE isEnabled='1'";
		$result - $this->connect->query($query);
		if($result)
		{
			while($app = mysqli_fetch_assoc($result))
			{
				$_SESSION['app'] = $app;
			}
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>Unable to load apps</div>";
			exit;
		}	
		
	}
}
$apps = new AppManager;