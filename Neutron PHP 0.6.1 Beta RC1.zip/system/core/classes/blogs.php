<?php

require_once("security.php");

class BlogManager extends Security
{
	public $pageID;
	public $totalPages;
	
	public function __construct()
	{
		if(isset($_REQUEST['pageID']))
		{
			$this->pageID = stripslashes($_REQUEST['pageID']);
		}
		else
		{
			$this->pageID = 1;
		}
		
		$this->mysqli = new Mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
		
		if(isset($_REQUEST['cmd']))
		{
			switch($_REQUEST['cmd'])
			{
				case "addLike":
					{
						$this->likeBlog($this->mysqli->real_escape_string($_REQUEST['blogID']));
						break;
					}
			}
		}
	}
	
	public function likeBlog($blogID)
	{
		if($blogID)
		{
			$query = "UPDATE blogs SET likes=likes+1 WHERE blogID='".$blogID."'";
			$result = $this->mysqli->query($query);
			if($result)
			{
				echo 1;
			}
			else
			{
				die("<div class='system error' style='display:block;'>Unable to update blogs</div>");
			}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Invalid blog ID</div>");
		}
	}
	
	public function paginate($class, $pageIndex)
	{
		?>
			<a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=1'>First</a>
			<style>
				.disabled
				{
					color:#eee;
					border:solid 1px #eee;
				}
				.disabled:hover
				{
					cursor:default;
					background:#fff;
					color:#eee;
					border:solid 1px #eee;
				}				
			</style>
		<?php
		
		if($_REQUEST['pageID'] == 1)
		{
			?>
				<a class='<?php echo $class;?> disabled' href='javascript:void(0)'>Prev</a>	
			<?php
		}
		else
		{
			?>
				<a class='<?php echo $class;?> ' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $_REQUEST['pageID'] - 1;?>'>Prev</a>	
			<?php			
		}		
		
		?>
			<a class='active <?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $_REQUEST['pageID'];?>'><?php echo $_REQUEST['pageID'];?></a>
		<?php		
		if($_REQUEST['pageID'] >= $this->totalPages)
		{
			?>
				<a class='<?php echo $class;?> disabled' href='javascript:void(0)'>Next</a>	
			<?php
		}
		else
		{
			?>
				<a class='<?php echo $class;?> ' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $_REQUEST['pageID'] + 1;?>'>Next</a>	
			<?php			
		}	

		?>
			<a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $this->totalPages + 2;?>'>Last</a>
		<?php			
		
	}	
	
	public function loadRecentBlogs($limit)
	{
		$query = "SELECT * FROM blogs WHERE isFeatured='1' ORDER BY dateCreated DESC";
		$result = $this->mysqli->query($query);
		if($result)
		{
			while($blog = mysqli_fetch_assoc($result))
			{
				if($blog['isEnabled'] == 1)
				{
					?>
						
								<a class='blog' href='index.php?page=blogs&blogID=<?php echo $blog['blogID'];?>' style='display:block;margin:10px;'>
									<div class='blogID' style='position:relative;float:left;font-weight:bold;'><?php echo $blog['blogID'];?></div>
									<a href='blogTitle' ><?php echo substr($blog['blogTitle'], 0, 30);?></a>
								</a>
								<br>
						
					<?php
				}
				else
				{
					die("<div class='system error' style='display:block;'>The blog $blogID has been disabled by the system administrator</div>");
				}
			}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to load blog data</div>");
		}
	}

	public function loadFeaturedBlogs($limit)
	{
		$query = "SELECT * FROM blogs WHERE isFeatured='1' ORDER BY rand()";
		$result = $this->mysqli->query($query);
		if($result)
		{
			while($blog = mysqli_fetch_assoc($result))
			{
				if($blog['isEnabled'] == 1)
				{
					?>
						
								<a class='blog' href='index.php?page=blogs&blogID=<?php echo $blog['blogID'];?>' style='display:block;margin:10px;'>
									<div class='blogID' style='position:relative;float:left;margin-right:20px;font-weight:bold;'><?php echo $blog['blogID'];?></div>
									<a href='index.php?page=blogs&blogID=<?php echo $blog['blogID'];?>' ><?php echo substr($blog['blogTitle'], 0, 30);?></a>
								</a>
								<br>
						
					<?php
				}
				else
				{
					die("<div class='system error' style='display:block;'>The blog $blogID has been disabled by the system administrator</div>");
				}
			}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to load blog data</div>");
		}
	}	
	
	
	public function loadBlogs()
	{
    	$offset = ($this->pageID - 1) * $_SESSION['config']['tableDisplayLimit'];
		
		$query = "SELECT * FROM blogs";
		$result = $this->mysqli->query($query);
		$totalRows = mysqli_num_rows($result);
  		$this->totalPages = ceil($totalRows / $_SESSION['config']['tableDisplayLimit']) - 2;		
		$query2 ="SELECT * FROM blogs LIMIT ".((int)$offset).",".$_SESSION['config']['tableDisplayLimit'];
		$result2 = $this->mysqli->query($query2);
		if($result2)
		{
			while($blog = mysqli_fetch_assoc($result2))
			{
				?>
					<tr>
						<td><?php echo $blog['blogID'];?></td>
						<td><?php echo $blog['blogTitle'];?></td>
						<td><?php echo $blog['name'];?></td>
						<td><?php echo $blog['label'];?></td>
						<td><?php echo $blog['dateCreated'];?></td>						
						<td><?php echo $blog['likes'];?></td>
						<td>
							<?php
								if($blog['isFeatured'] == 1)
								{
									?>
									<div class='label success'>Yes</div>
									<?php
								}
								else
								{
									?>
									<div class='label error'>No</div>
									<?php
								}
							?>								
						</td>
						<td>
							<?php
								if($blog['isEnabled'] == 1)
								{
									?>
									<div class='label success'>Yes</div>
									<?php
								}
								else
								{
									?>
									<div class='label error'>No</div>
									<?php
								}
							?>								
						</td>
						<td style='text-indent:0px;margin-left:0px;'>
							<a href='javascript:void(0)' onclick='deleteBlog(<?php echo $blog['blogID'];?>'><i class='fa fa-trash'></i></a>
							<a href='javascript:void(0)' onclick='editBlog(<?php echo $blog['blogID'];?>'><i class='fa fa-pencil'></i></a>	
						</td>					
					</tr>
				<?php
			}			
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to load blog data</div>");
		}
	}
	
	public function loadBlog($blogID)
	{
		if($blogID)
		{
			$query = "SELECT * FROM blogs WHERE blogID='".$blogID."'";
			$result = $this->mysqli->query($query);
			if($result)
			{
				while($blog = mysqli_fetch_assoc($result))
				{
					?>
						<div class='panel blog' style='padding:0px;margin-top:0px;width:880px;'>
							<div class='panelTitle'><?php echo $blog['blogTitle'];?><a href='javascript:void(0)' style='position:relative;float:right;right:25px;top:5px;' onclick='likeBlog(<?php echo $blog['blogID'];?>)'><i class='fa fa-heart-o'></i></a></div>
							<div class='inner' style='padding:20px;' >
								<div class='category'><?php echo $blog['category'];?></div>
								<br>
								<div class='author' >by <?php echo $blog['authors'];?></div>
								<br>
								<div class='date' ><?php echo $blog['dateCreated'];?></div>
								<br>
								<div class='content'>
									<?php echo $blog['content'];?>
								</div>							
							</div>
						</div>
					<?php					
				}
			}
			else
			{
				die("<div class='system error' style='display:block;'>Unable to load blog data</div>");
			}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Invalid blog ID $blogID</div>");
		}
	}
	
	public function loadFeatured($limit)
	{
		$query = "SELECT * FROM blogs ORDER by dateCreated LIMIT $limit";
		$result = $this->mysqli->query($query);
		if($result)
		{
				while($blog = mysqli_fetch_assoc($result))
				{
					?>
						<div class='panel blog' style='width:880px;height:auto;position:relative;float:left;'>
							<div class='panelTitle'><?php echo $blog['blogTitle'];?><a href='javascript:void(0)' style='position:relative;float:right;right:25px;top:5px;' onclick='likeBlog(<?php echo $blog['blogID'];?>)'><i class='fa fa-heart-o'></i></a></div>
							<div class='inner' style='padding:20px;'>
							<label class='label success'><?php echo $blog['category'];?></label>
								<br><br>
								<div class='author' >by <?php echo $blog['authors'];?></div>
								<br>
								<div class='date' ><?php echo $blog['dateCreated'];?></div>
								<br>
								<div class='content'>
									<?php echo substr($blog['content'], 0, 600);?>...
								</div>				
								<br>
								<a href='index.php?page=blogs&blog=<?php echo $blog['blogID'];?>' class='button viewMore'>Read more</a>
							</div>
						</div>
					<?php					
				}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to load blog data</div>");
		}
	}	
	
	public function loadRecent($limit)
	{
		$query = "SELECT * FROM blogs ORDER by rand() WHERE isFeatured='1' LIMIT ".$limit;
		$result = $this->mysqli->query($query);
		if($result)
		{
			while($blog = mysqli_fetch_assoc($result))
			{
				?>
						<div class='panel blog' style='padding:0px;margin-top:20px;width:880px;'>
							<div class='panelTitle'><?php echo $blog['blogTitle'];?><a href='javascript:void(0)' style='position:relative;float:right;right:25px;top:5px;' onclick='likeBlog(<?php echo $blog['blogID'];?>)'><i class='fa fa-heart-o'></i></a></div>
							<div class='inner' >
								<br>
								<div class='author' >by <?php echo $blog['authors'];?></div>
								<br>
								<div class='date' ><?php echo $blog['dateCreated'];?></div>
								<br>
								<div class='content'>
									<?php echo $blog['content'];?>
								</div>							
							</div>
						</div>

				<?php
			}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to load blog data</div>");
		}
	}
}
$blogs = new BlogManager;