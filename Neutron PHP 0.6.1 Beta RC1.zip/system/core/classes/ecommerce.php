<?php

require_once("config.php");

class eCommerce extends Config
{
	public $connect;
	
	public function __construct()
	{
		$this->connect = new Mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
	}
	
	public function loadInvoices($limit)
	{
		$query = "select * FROM invoices LIMIT $limit";
		$result = $this->connect->query($query);
		if($result)
		{
			while($invoices = mysqli_fetch_assoc($result))
			{
				?>
					<a href='index.php?page=ecommerce&invoiceID=<?php echo $invoices['invoiceID'];?>' class='invoice' data='<?php echo $invoices['invoiceID'];?>'>
						<div class='date' style='position:relative;float:right;top:-10px;right:5px;font-size:13px;'>09/18/2023 22:05 PM</div>
						<div class='title' style='font-weight:bold;width:100%;'><?php echo $invoices['invoiceID']." ".substr($invoices['title'], 0, -1);?></div>
						<div class='payment status' style='margin-top:3px;'>
							<?php 
								if($invoices['isPaid'] == 1)
								{
									?>
										<div style='position:relative;float:left;margin-top:0px;margin-right:20px;' class='label success'>Paid</div>
									<?php									
								}
								else
								{
									?>
										<div style='position:relative;float:left;margin-top:0px;margin-right:20px;' class='label error'>Not Paid</div>
									<?php
								}
							?>
							
							$<?php echo $invoices['totalAmount'];?>
							
						</div>
					</a>
				<?php
			}
		}
		else
		{
			echo "<div class='system error' style='display:block;'>Unable to load invoices</div>";
		}
	}
	
	public function loadProducts()
	{
		$query = "SELECT * FROM products";
		$result = $this->connect->query($query);
		if($result)
		{
			while($product = mysqli_fetch_assoc($result))
			{
				
				$features = explode(",",$product['features']);			
				
				?>
					<div class='product panel' style='text-align:center;margin-top:20px;width:250px;height:350px;border:solid 1px #ddd;margin-right:20px;display:block;position:relative;float:left;'>
						<div class='panelTitle'><?php echo $product['productName'];?></div>
						<br>
						<img src='../../../global/img/<?php echo $product['logo'];?>' height="40" width="40">
						<br><br>
						<?php
							foreach($features as $feature => $value)
							{
								echo "<span style='display:block;width:100%;text-align:left;'><i style='position:relative;float:left;top:3px;left:0px;margin:0px 10px;' class='fa fa-check'></i>".$value."</span><br>";
							}
						?>
						<div class='price'><?php echo $product['price'];?></div>
						<div class='buttonctrl' style='position:absolute;bottom:20px;text-align:center;width:100%;'>
							<a class='button' style='margin:0px 5px;' href='https://www.paypal.com/donate/?hosted_button_id=NHVWMYEJBTPMN'>Buy</a>
							<a class='button' style='margin:0px 5px;' href='https://demos.luvbytesllc.com/index.php?&productID=<?php echo $product['productID'];?>'>Demo</a>						
						</div>
					</div>
				<?php
			}
		}
		else
		{
			echo "<div class='system error' style='display:block;'>Unable to load product table</div>";
			exit
		}
	}	
}
$ecommerce = new eCommerce;