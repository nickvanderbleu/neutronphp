<?php

require_once("tools.php");

class Registry extends Tools
{
	public $file = "registry.ini";
	
	public function __construct()
	{
		$this->loadRegistry($_SESSION['configPath'].$this->ds.$this->file);
		
		date_default_timezone_set($_SESSION['registry']['defaultTimezone']);
	}
	
	public function loadRegistry($file)
	{
		if($this->checkFile($file) == 1)
		{
			$this->parseINI($file, true);
			
			return $_SESSION['registry'];
		}
		else
		{
			echo "<div class='systemBar error' style='display:block;'>The registry file is invalid</div>";
			exit;
		}
	}
}
$registry = new Registry;