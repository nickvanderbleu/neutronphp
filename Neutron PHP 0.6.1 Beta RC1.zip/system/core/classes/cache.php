<?php

require_once("config.php");

class CacheManager extends Config
{
	public $cacheDir;
	public $file;
	public $cacheFile;
	
	public function __construct()
	{
		if(isset($_REQUEST['page']))
		{
			$this->file = md5(stripslashes($_REQUEST['page']));			
		}
		else
		{
			$this->file = md5('index');
		}
		
		$this->cachePath = $this->sysDir.$this->ds.$_SESSION['config']['dataDir'].$this->ds.$_SESSION['config']['cacheDir'];
			
		$this->cacheFile = $this->cachePath.$this->ds.$this->file;
		
		
	}
	
	public function writeCache($file)
	{
		$cached = fopen($file, 'w');
		fwrite($cached, ob_get_contents());
		fclose($cached);
		ob_end_flush(); // Send the output to the browser	
	}
	
	public function loadCache($file)
	{
		require_once($file);
	}
	
	public function checkCache($file)
	{
		if (file_exists($file) && time() - $_SESSION['config']['cacheTTL'] <= filemtime($file)) 
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
}
$cache = new CacheManager;