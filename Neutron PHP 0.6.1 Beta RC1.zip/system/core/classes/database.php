<?php

require_once("connect.php");

class FirecodeDB extends Connect
{
	public $connect;
	public $dbStatus;
	
	public function __construct()
	{
		$this->connect = new MySQLi($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->dbport);
	}
	
public function loadTableData($database, $table)
{
    // Assuming you have a database connection established
    // and the necessary credentials set up

    // Select the database using $this->connect
    mysqli_select_db($this->connect, $database);

    // Query to fetch data from the specified table
    $query = "SELECT * FROM $table";

    // Execute the query and fetch the results
    // (Replace this with your actual database query execution)
    $results = $this->connect->query($query);

    // Create an HTML table
    echo "<table class='tableList panel' cellpadding='0' cellspacing='0'>";
                echo "<thead>";
				echo "<tr>";
    // Create the table header (thead) with column labels
    $first_row = true; // To handle the first row separately
    while ($row = mysqli_fetch_assoc($results)) {
        foreach ($row as $col => $value) {
            if ($first_row) {
                // Display column names in the header

				echo "<td style='width:100px;border-bottom:solid 1px #ddd;padding:10px 15px;'>$col</td>";

            }
        }
        $first_row = false;
    }
	echo "</tr>";
	echo "</thead>";

    // Create the table body (tbody) with data rows
    echo "<tbody>";
    mysqli_data_seek($results, 0); // Reset result pointer
    while ($row = mysqli_fetch_assoc($results)) {
        echo "<tr>";
        $first_col = true; // To handle the first column separately
        foreach ($row as $col => $value) {
            if ($first_col) {
                // Display labels in the first column
                echo "<td style='padding:10px 15px;border-bottom:solid 1px #ddd;text-indent:20px;'>$value</td>";
            } else {
                // Make other cells editable
                echo "<td style='padding:10px 15px;border-bottom:solid 1px #ddd;text-indent:20px;' contenteditable='true'>$value</td>";
            }
            $first_col = false;
        }
        echo "</tr>";
    }
    echo "</tbody>";

    // Close the table
    echo "</table>";
}
	public function loadTables($database)
	{
		$sql = "SHOW TABLES in $database";
		$result = $this->connect->query($sql);

       if ($result->num_rows > 0) {
            $count = 0;
            echo '<div style="display: flex; overflow-x: auto;">';
            echo '<div style="flex: 0 0 auto; margin-right: 20px;">';
            while($row = $result->fetch_assoc()) {
                ?><span class='tableLink' style='display:block;padding:1px 0px;'><i style='margin-right:15px;' class='fa fa-table'></i><a href='index.php?page=tables&database=<?php echo $database;?>&table=<?php echo $row["Tables_in_" . $database];?>'><?php echo $row["Tables_in_" . $database];?></a></span><br><?php
                $count++;
                if ($count % 19 == 0) {
                    echo '</div><div style="flex: 0 0 auto; margin-right: 20px;">';
                }
            }
            echo '</div></div>';
        } else {
            echo "No tables found.";
        }	
	}
	
	public function loadDatabases()
	{
		$query = "SHOW DATABASES";
		$result = $this->connect->query($query);

		if ($result->num_rows > 0) {
			
			$this->dbStatus = 1;
			
			while($row = $result->fetch_assoc()) {
				?><span class='link'><i class='fa fa-database'></i><a href='index.php?page=dashboard&database=<?php echo $row['Database'];?>'><?php echo $row['Database'];?></a></span><?php
			}
		} else {
			echo "No databases found.";
		}		
	}
}
$firecode = new FirecodeDB;