<?php

require_once("license.php");

class System extends LicenseManager
{
	public $mysqli;
	public $systemStatus;
	public $token;
	public $systemID = 1000;
	
	public function __construct()
	{
		$this->connect = new MySQLi($_SESSION['connect']['dbhost'], $_SESSION['connect']['dbuser'], $_SESSION['connect']['dbpass'], $_SESSION['connect']['dbname'], $_SESSION['connect']['dbport']);
		
		if(isset($_REQUEST['cmd']))
		{
			switch($_REQUEST['cmd'])
			{
				case "updateParam":
					{
						$this->updateParam($_REQUEST['param'], $_REQUEST['value']);
						break;
					}
			}
		}			
	}
	
	function getDriveSpaceUsage() {
		$totalSpace = disk_total_space("/");
		$freeSpace = disk_free_space("/");
		$usedSpace = $totalSpace - $freeSpace;
		$usedPercentage = ($usedSpace / $totalSpace) * 100;
		return round($usedPercentage, 2);
	}	
	
	
	function updateParam($param, $value)
	{
		$query = "UPDATE config SET $param='".$value."'";
		$result = $this->mysqli->query($query);
		if($result)
		{
			$_SESSION['config'][$param]	= $value;
			
			echo 1;
		}
		else
		{
			echo "Unable to update $param";
		}
	}
}
$system = new System;