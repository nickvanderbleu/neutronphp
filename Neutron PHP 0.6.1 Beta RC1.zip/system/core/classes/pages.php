<?php

require_once("config.php");

class Pages extends Config
{    
    public $connect;
    public $page;
    public $pageIndex;
    public $totalPages;

    public function __construct()
    {
        $this->pageID = isset($_REQUEST['pageID']) ? (int)$_REQUEST['pageID'] : 1;
        $this->pageIndex = isset($_REQUEST['page']) ? htmlspecialchars($_REQUEST['page'], ENT_QUOTES, 'UTF-8') : 'index';
        $this->loadPage($this->pageIndex);
    }
        
    public function loadPage($pageIndex)
    {
		$this->connect = new MySQLi($_SESSION['connect']['dbhost'], $_SESSION['connect']['dbuser'], $_SESSION['connect']['dbpass'], $_SESSION['connect']['dbname'], $_SESSION['connect']['dbport']);
        
        if ($pageIndex) {
            $query = "SELECT * FROM pages WHERE pageIndex='" . $this->connect->real_escape_string($pageIndex) . "'";
            $result = $this->connect->query($query);
            if ($result) {
                while ($page = mysqli_fetch_assoc($result)) {
                    $_SESSION['page'] = $page;
                    $this->label = $page['label'];
                }
            } else {
                echo "<div class='systemBar error' style='display:block;'>Unable to load page data for page ID $this->pageID</div>";
                exit;
            }
        } else {
            echo "<div class='systemBar error' style='display:block;'>Invalid page ID</div>";
            exit;
        }
    }
    
    public function paginate($class, $pageIndex)
    {
        ?>
            <a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=1'>First</a>
            <style>
                .disabled {
                    color: #eee;
                    border: solid 1px #eee;
                }
                .disabled:hover {
                    cursor: default;
                    background: #fff;
                    color: #eee;
                    border: solid 1px #eee;
                }                
            </style>
        <?php
        
        if ($_REQUEST['pageID'] == 1) {
            ?>
                <a class='<?php echo $class;?> disabled' href='javascript:void(0)'>Prev</a>    
            <?php
        } else {
            ?>
                <a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo (int)$_REQUEST['pageID'] - 1;?>'>Prev</a>    
            <?php            
        }        
        
        ?>
            <a class='active <?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo (int)$_REQUEST['pageID'];?>'><?php echo (int)$_REQUEST['pageID'];?></a>
        <?php        
        if ($_REQUEST['pageID'] >= $this->totalPages + 2) {
            ?>
                <a class='<?php echo $class;?> disabled' href='javascript:void(0)'>Next</a>    
            <?php
        } else {
            ?>
                <a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo (int)$_REQUEST['pageID'] + 1;?>'>Next</a>    
            <?php            
        }    

        ?>
            <a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $this->totalPages + 2;?>'>Last</a>
        <?php            
    }        
        
    public function loadPages($limit)
    {
        $offset = (($this->pageID - 1) * $limit);
        
        $query = "SELECT * FROM pages";
        $result = $this->connect->query($query);
        $totalRows = mysqli_num_rows($result);
        $this->totalPages = ceil($totalRows / $limit) - 2;        
        $query2 = "SELECT * FROM pages LIMIT " . ((int)$offset) . "," . $limit;
        $result2 = $this->connect->query($query2);
        if ($result2) {
            while ($pages = mysqli_fetch_assoc($result2)) {
                ?>
                    <tr>
                        <td><?php echo $pages['pageID'];?></td>
                        <td><?php echo htmlspecialchars($pages['pageName'], ENT_QUOTES, 'UTF-8');?></td>
                        <td><?php echo htmlspecialchars($pages['label'], ENT_QUOTES, 'UTF-8');?></td>
                        <td><?php echo htmlspecialchars($pages['page'], ENT_QUOTES, 'UTF-8');?></td>
                        <td><?php echo htmlspecialchars($pages['pageIndex'], ENT_QUOTES, 'UTF-8');?></td>
                        <td>
                            <?php
                                switch ($pages['isLocked']) {
                                    case 0:
                                        ?>
                                            <span class='label success' style='width:100px;'>No</span>
                                        <?php
                                        break;
                                    case 1:
                                        ?>
                                            <span class='label error' style='width:100px;'>Yes</span>
                                        <?php
                                        break;                                    
                                }
                            ?>
                        </td>
						<td>
							<a href='javascript:void(0)' pageID='<?php echo $pages['pageID'];?>' onclick='lockPage($(this).attr("pageID")'><i class='fa fa-lock'></i></a>
							<a href='javascript:void(0)' pageID='<?php echo $pages['pageID'];?>' onclick='lockPage($(this).attr("pageID")'><i class='fa fa-trash'></i></a>
							<a href='javascript:void(0)' pageID='<?php echo $pages['pageID'];?>' onclick='lockPage($(this).attr("pageID")'><i class='fa fa-pencil'></i></a>
						</td>
                <?php
            }
        }
    }
	public function checkPage($pageIndex)
	{
		if($pageIndex)
		{
			$query = "SELECT * FROM pages WHERE pageIndex='".$pageIndex."'";
			$result = $this->connect->query($query);
			if($result)
			{
				while($pages = mysqli_fetch_assoc($result))
				{
					if($pages['isLocked'] == 1)
					{
						return 1;
					}
					else
					{
						return 0;
					}
				}
			}
			else
			{
				die("<div class='systemBar error' style='display:block;' data='006'>".$this->loadError('006')." $pageIndex</div>");
			}
		}
		else
		{
			die("<div class='systemBar error' style='display:block;' data='007'>".$this->loadError('007')."</div>");
		}
	}	
	
}
$pages = new Pages;
?>