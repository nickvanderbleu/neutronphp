<?php
class Browser {
    private $browserName;
    private $browserVersion;
    private $isCompatible;

    public function __construct() {
        $this->detectBrowser();
        $this->isCompatible = false;
    }

    private function detectBrowser() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'];

        if (preg_match('/Chrome\/([0-9.]+)/', $userAgent, $matches)) {
            $this->browserName = 'Chrome';
            $this->browserVersion = (int)$matches[1];
        } elseif (preg_match('/Firefox\/([0-9.]+)/', $userAgent, $matches)) {
            $this->browserName = 'Firefox';
            $this->browserVersion = (int)$matches[1];
        } elseif (preg_match('/Safari\/([0-9.]+)/', $userAgent, $matches) && !preg_match('/Chrome/', $userAgent)) {
            $this->browserName = 'Safari';
            $this->browserVersion = (int)$matches[1];
        } elseif (preg_match('/Edg\/([0-9.]+)/', $userAgent, $matches)) {
            $this->browserName = 'Edge';
            $this->browserVersion = (int)$matches[1];
        } else {
            $this->browserName = 'Unknown';
            $this->browserVersion = 0;
        }
    }

    public function checkCompatibility() {
        if (!isset($_SESSION['config']['enableBrowserCheck']) || !$_SESSION['config']['enableBrowserCheck']) {
            return 1; // Check is disabled
        }

        switch (strtolower($this->browserName)) {
            case 'chrome':
                $this->isCompatible = $this->browserVersion >= 80;
                break;
            case 'firefox':
                $this->isCompatible = $this->browserVersion >= 75;
                break;
            case 'safari':
                $this->isCompatible = $this->browserVersion >= 13;
                break;
            case 'edge':
                $this->isCompatible = $this->browserVersion >= 80;
                break;
            default:
                $this->isCompatible = false;
        }

        return $this->isCompatible ? 1 : 0;
    }

    public function getBrowserInfo() {
        return [
            'name' => ucfirst($this->browserName),
            'version' => $this->browserVersion,
            'isCompatible' => $this->isCompatible ? 'Compatible' : 'Not Compatible'
        ];
    }
}
$browser = new Browser;