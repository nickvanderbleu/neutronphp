<?php

require_once("config.php");

class Paginate extends Config
{
	public $pageID;
	public $totalPages;
	
	public function __construct()
	{

	}
	
	public function getLinks($class, $pageIndex, $totalPages)
	{
		?>
			<a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=1'>First</a>
			<style>
				.disabled
				{
					color:#eee;
					border:solid 1px #eee;
				}
				.disabled:hover
				{
					cursor:default;
					background:#fff;
					color:#eee;
					border:solid 1px #eee;
				}				
			</style>
		<?php
		
		if($_REQUEST['pageID'] == 1)
		{
			?>
				<a class='<?php echo $class;?> disabled' href='javascript:void(0)'>Prev</a>	
			<?php
		}
		else
		{
			?>
				<a class='<?php echo $class;?> ' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $_REQUEST['pageID'] - 1;?>'>Prev</a>	
			<?php			
		}		
		
		?>
			<a class='active <?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $_REQUEST['pageID'];?>'><?php echo $_REQUEST['pageID'];?></a>
		<?php		
		if($_REQUEST['pageID'] > ceil($this->totalPages))
		{
			?>
				<a class='<?php echo $class;?> disabled' href='javascript:void(0)'>Next</a>	
			<?php
		}
		else
		{
			?>
				<a class='<?php echo $class;?> ' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $_REQUEST['pageID'] + 1;?>'>Next</a>	
			<?php			
		}	

		?>
			<a class='<?php echo $class;?>' href='index.php?page=<?php echo $pageIndex;?>&pageID=<?php echo $this->totalPages + 2;?>'>Last</a>
		<?php			
		
	}
}
$paginate = new Paginate;