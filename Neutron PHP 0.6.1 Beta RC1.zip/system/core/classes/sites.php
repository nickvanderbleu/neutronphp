<?php

require_once("pages.php");

class SiteManager extends Pages
{
    public $defaultSiteID;
    public $connect;
    public $siteToken;
    public $siteDir = "sites";
    public $pageID;

    public function __construct()
    {
		$this->connect = new MySQLi($_SESSION['connect']['dbhost'], $_SESSION['connect']['dbuser'], $_SESSION['connect']['dbpass'], $_SESSION['connect']['dbname'], $_SESSION['connect']['dbport']);

        if ($this->connect->connect_error) {
            echo "<div class='system error' style='display:block;'>Connection failed: " . $this->connect->connect_error . "</div>";
            exit;
        }

        if (!isset($this->defaultSiteID)) {
            $this->defaultSiteID = $_SESSION['config']['configID'];
            $this->siteToken = md5($this->defaultSiteID);
        } else {
            if (isset($_REQUEST['siteID'])) {
                $this->defaultSiteID = htmlspecialchars($_REQUEST['siteID'], ENT_QUOTES, 'UTF-8');
            } else {
                $this->defaultSiteID = 1000;
            }
            $this->siteToken = md5($this->defaultSiteID);
        }

        if (isset($_REQUEST['pageID'])) {
            $this->pageID = htmlspecialchars($_REQUEST['pageID'], ENT_QUOTES, 'UTF-8');
        } else {
            $this->pageID = 1;
        }

        $this->loadDefaultSite($this->defaultSiteID);
    }

    public function paginate($class, $pageIndex)
    {
        ?>
        <a class='<?php echo $class; ?>' href='index.php?page=<?php echo $pageIndex; ?>&pageID=1'>First</a>
        <style>
            .disabled {
                color: #eee;
                border: solid 1px #eee;
            }

            .disabled:hover {
                cursor: default;
                background: #fff;
                color: #eee;
                border: solid 1px #eee;
            }
        </style>
        <?php

        if ($_REQUEST['pageID'] == 1) {
            ?>
            <a class='<?php echo $class; ?> disabled' href='javascript:void(0)'>Prev</a>
            <?php
        } else {
            ?>
            <a class='<?php echo $class; ?>' href='index.php?page=<?php echo $pageIndex; ?>&pageID=<?php echo $_REQUEST['pageID'] - 1; ?>'>Prev</a>
            <?php
        }

        ?>
        <a class='active <?php echo $class; ?>' href='index.php?page=<?php echo $pageIndex; ?>&pageID=<?php echo $_REQUEST['pageID']; ?>'><?php echo $_REQUEST['pageID']; ?></a>
        <?php

        if ($_REQUEST['pageID'] >= $this->totalPages) {
            ?>
            <a class='<?php echo $class; ?> disabled' href='javascript:void(0)'>Next</a>
            <?php
        } else {
            ?>
            <a class='<?php echo $class; ?>' href='index.php?page=<?php echo $pageIndex; ?>&pageID=<?php echo $_REQUEST['pageID'] + 1; ?>'>Next</a>
            <?php
        }

        ?>
        <a class='<?php echo $class; ?>' href='index.php?page=<?php echo $pageIndex; ?>&pageID=<?php echo $this->totalPages + 2; ?>'>Last</a>
        <?php
    }

    public function loadDefaultSite($defaultSiteID)
    {
        $query = $this->connect->prepare("SELECT * FROM sites WHERE siteID=? AND isDefault='1'");
        $query->bind_param("i", $defaultSiteID);
        $query->execute();
        $result = $query->get_result();

        if ($result) {
            while ($site = $result->fetch_assoc()) {
                $_SESSION['site'] = $site;
            }
        } else {
            echo "<div class='system error' style='display:block;'>Unable to load default site</div>";
            exit;
        }
    }

    public function loadSites()
    {
        $offset = (((int)$this->pageID - 1) * $_SESSION['config']['tableDisplayLimit']);

        $query = "SELECT * FROM sites";
        $result = $this->connect->query($query);
        $totalRows = $result->num_rows;
        $this->totalPages = ceil($totalRows / $_SESSION['config']['tableDisplayLimit']) - 2;

        $query2 = $this->connect->prepare("SELECT * FROM sites LIMIT ?, ?");
        $query2->bind_param("ii", $offset, $_SESSION['config']['tableDisplayLimit']);
        $query2->execute();
        $result2 = $query2->get_result();

        if ($result2) {
            while ($sites = $result2->fetch_assoc()) {
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($sites['siteID'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($sites['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($sites['companyName'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($sites['companyEmail'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($sites['contactPhone'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($sites['dateCreated'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($sites['theme'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td style='text-indent:0px;margin-left:0px;'>
                        <a href='javascript:void(0)' onclick='deleteSite(<?php echo $sites['siteID']; ?>)'><i class='fa fa-trash'></i></a>
                        <a href='javascript:void(0)' onclick='editSite(<?php echo $sites['siteID']; ?>)'><i class='fa fa-pencil'></i></a>
                        <?php
                        if ($sites['isDefault'] == 1) {
                            ?>
                            <a href='javascript:void(0)' onclick='setDefault(<?php echo $sites['siteID']; ?>)' class='favoriteSite'><i class='active fa fa-star-o'></i></a>
                            <?php
                        } else {
                            ?>
                            <a href='javascript:void(0)' onclick='setDefault(<?php echo $sites['siteID']; ?>)' class='favoriteSite'><i class='fa fa-star-o'></i></a>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <?php
            }
        } else {
            echo "<div class='system error' style='display:block;'>Unable to load site data</div>";
            exit;
        }
    }
}

$sites = new SiteManager;