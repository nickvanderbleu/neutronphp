<?php

// File Version 1.0

require_once("classes/registry.php");
require_once("classes/errors.php");
require_once("classes/config.php");
require_once("classes/about.php");
require_once("classes/pages.php");
require_once("classes/security.php");
require_once("classes/cache.php");
require_once("classes/languages.php");
require_once("classes/translate.php");
require_once("classes/templates.php");
require_once("classes/sites.php");
require_once("classes/system.php");

