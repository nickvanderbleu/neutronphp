<link href='/global/css/system.css' rel='stylesheet'>
<link href='/global/css/ui.css' rel='stylesheet'>
<link href='/global/css/global.css' rel='stylesheet'>
<?php

require_once("core/classes/tools.php");
require_once("core/classes/connect.php");
require_once("core/classes/registry.php");
require_once("core/classes/browser.php");

if ($browser->checkCompatibility() <= '120') {
    if ($tools->checkFile($_SESSION['configPath'] . $tools->ds . $connect->file) == 1) {
        require_once("core/autoload.php");

        ob_start();

        if ($pages->checkPage($pages->pageIndex) == 0) {
            if ($_SESSION['config']['enableCache'] == 1 && $_SESSION['page']['noCache'] == 0) {
                if ($cache->checkCache($cache->cacheFile) == 1) {
                    $cache->loadCache($cache->cacheFile);

                    $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Cache", 0);
                } else {
                    if ($_SESSION['config']['enableTranslation'] == 1 && isset($_REQUEST['language']) && $_REQUEST['language'] != $_SESSION['registry']['defaultLanguage']) {
                        if (isset($_REQUEST['language'])) {
                            $translate->loadTranslation(stripslashes($_REQUEST['language']), $pages->pageIndex);

                            $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $security->page, $pages->pageIndex, "Translation", 0);
                        } else {
                            $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, $errors->loadError('009'), 1);

                            echo "<div class='systemBar error' style='display:block;' data='009'>" . htmlspecialchars($errors->loadError('009'), ENT_QUOTES, 'UTF-8') . "</div>";
                            exit;
                        }
                    } else {
                        if ($_SERVER['HTTP_HOST'] == 'localhost') {
                                if ($_SERVER['REQUEST_URI'] == '/' || ($_SERVER['REQUEST_URI'] == '/' && isset($_SERVER['QUERY_STRING']))) {
                                    if ($_SESSION['config']['enableSite'] == 1) {
                                        $templates->loadTemplate($_SESSION['config']['siteTheme'], $pages->pageIndex);

                                        $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Site", 0);
                                    } else {
                                        echo "<div class='systemBar error' style='display:block;' data='014'>" . htmlspecialchars($errors->loadError('014'), ENT_QUOTES, 'UTF-8') . "</div>";
                                        exit;
                                    }
                                } else {
                                    if ($_SESSION['config']['enableAdmin'] == 1) {
                                        $templates->loadTemplate($_SESSION['config']['adminTheme'], $pages->pageIndex);

                                        $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Admin", 0);
                                    } else {
                                        echo "<div class='systemBar error' style='display:block;' data='013'>" . htmlspecialchars($errors->loadError('013'), ENT_QUOTES, 'UTF-8') . "</div>";
                                        exit;
                                    }
                                }
                        } else {
                            if ($security->checkBlacklist($security->ipAddress) == 0) {
                                if ($_SERVER['REQUEST_URI'] == '/' || ($_SERVER['REQUEST_URI'] == '/' && isset($_SERVER['QUERY_STRING']))) {
                                    if ($_SESSION['config']['enableSite'] == 1) {
                                        $templates->loadTemplate($_SESSION['config']['siteTheme'], $pages->pageIndex);

                                        $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Site", 0);
                                    } else {
                                        echo "<div class='systemBar error' style='display:block;' data='014'>" . htmlspecialchars($errors->loadError('014'), ENT_QUOTES, 'UTF-8') . "</div>";
                                        exit;
                                    }
                                } else {
                                    if ($_SESSION['config']['enableAdmin'] == 1) {
                                        $templates->loadTemplate($_SESSION['config']['adminTheme'], $pages->pageIndex);

                                        $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Admin", 0);
                                    } else {
                                        echo "<div class='systemBar error' style='display:block;' data='013'>" . htmlspecialchars($errors->loadError('013'), ENT_QUOTES, 'UTF-8') . "</div>";
                                        exit;
                                    }
                                }
                            } else {
                                echo "<div class='systemBar error' style='display:block;' data='010'>" . htmlspecialchars($errors->loadError('010'), ENT_QUOTES, 'UTF-8') . "</div>";
                                exit;
                            }
                        }
                    }
                }

                $cache->writeCache($cache->cacheFile);
            } else {
                if ($_SESSION['config']['enableTranslation'] == 1 && isset($_REQUEST['language']) && $_REQUEST['language'] != $_SESSION['registry']['defaultLanguage']) {
                    if (isset($_REQUEST['language'])) {
                        $translate->loadTranslation(stripslashes($_REQUEST['language']), $pages->pageIndex);

                        $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Translation", 0);
                    } else {
                        $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, $errors->loadError('009'), 1);

                        echo "<div class='systemBar error' style='display:block;' data='009'>" . htmlspecialchars($errors->loadError('009'), ENT_QUOTES, 'UTF-8') . "</div>";
                        exit;
                    }
                } else {
                    if ($_SERVER['HTTP_HOST'] == 'localhost') {
                        if ($_SERVER['REQUEST_URI'] == '/' || ($_SERVER['REQUEST_URI'] == '/' && isset($_SERVER['QUERY_STRING']))) {
                            if ($_SESSION['config']['enableSite'] == 1) {
                                $templates->loadTemplate($_SESSION['config']['siteTheme'], $pages->pageIndex);

                                $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Site", 0);
                            } else {
                                echo "<div class='systemBar error' style='display:block;' data='014'>" . htmlspecialchars($errors->loadError('014'), ENT_QUOTES, 'UTF-8') . "</div>";
                                exit;
                            }
                        } else {
                            if ($_SESSION['config']['enableAdmin'] == 1) {
                                $templates->loadTemplate($_SESSION['config']['adminTheme'], $pages->pageIndex);

                                $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Admin", 0);
                            } else {
                                echo "<div class='systemBar error' style='display:block;' data='013'>" . htmlspecialchars($errors->loadError('013'), ENT_QUOTES, 'UTF-8') . "</div>";
                                exit;
                            }
                        }
                    } else {
                        if ($security->checkBlacklist($security->ipAddress) == 0) {
                            if ($_SERVER['REQUEST_URI'] == '/' || ($_SERVER['REQUEST_URI'] == '/' && isset($_SERVER['QUERY_STRING']))) {
                                if ($_SESSION['config']['enableSite'] == 1) {
                                    $templates->loadTemplate($_SESSION['config']['siteTheme'], $pages->pageIndex);

                                    $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Site", 0);
                                } else {
                                    echo "<div class='systemBar error' style='display:block;' data='014'>" . htmlspecialchars($errors->loadError('014'), ENT_QUOTES, 'UTF-8') . "</div>";
                                    exit;
                                }
                            } else {
                                if ($_SESSION['config']['enableAdmin'] == 1) {
                                    $templates->loadTemplate($_SESSION['config']['adminTheme'], $pages->pageIndex);

                                    $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, "Admin", 0);
                                } else {
                                    echo "<div class='systemBar error' style='display:block;' data='013'>" . htmlspecialchars($errors->loadError('013'), ENT_QUOTES, 'UTF-8') . "</div>";
                                    exit;
                                }
                            }
                        } else {
                            echo "<div class='systemBar error' style='display:block;' data='010'>" . htmlspecialchars($errors->loadError('010'), ENT_QUOTES, 'UTF-8') . "</div>";
                            exit;
                        }
                    }
                }
            }
        } else {
            $security->createLog($_SERVER['HTTP_HOST'], $security->ipAddress, $pages->page, $pages->pageIndex, $errors->loadError('008'), 1);

            echo "<div class='systemBar error' style='display:block;' errorID='008'>" . htmlspecialchars($errors->loadError('008'), ENT_QUOTES, 'UTF-8') . "</div>";
            exit;
        }
    } else {
        require_once("core/classes/errors.php");

        echo "<div class='systemBar error' style='display:block;' errorID='005'>" . htmlspecialchars($errors->loadError('005'), ENT_QUOTES, 'UTF-8') . "</div>";
        exit;
    }
} else {
    echo "<div class='systemBar error' style='display:block;' errorID='005'>Invalid browser version</div>";
    exit;
}